import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { cn, getEmbedUrl } from "@/lib/utils";
import { getExercises, saveExercises, getPrograms, savePrograms, saveVimeoToken, getMembers, getMemberActivity, sendNotification, getAnthropicKey, saveAnthropicKey, getVimeoToken, getHabits, getWorkoutsOfWeek, saveWorkoutOfWeek, getAppSettings, saveAppSettings, getExerciseEnrichment } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Dumbbell, PlayCircle, GripVertical, Copy, Video, Loader2, Edit, Users, History, Calendar as CalendarIcon, Bell, Send, Download, Link2, Link2Off, Heading, Upload, Sparkles, Check, ChevronsUpDown } from "lucide-react";
import JSZip from "jszip";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { toast } from "sonner";
import { Navigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";


// Real cardio machines, by day (varied). Ordered; Day N uses index (N-1) % length.
const CARDIO_MACHINES = [
  { name: "Bike Erg", id: "bike-erg" },
  { name: "Ski Erg", id: "ski-erg" },
  { name: "Rower", id: "rower" },
  { name: "Air Bike", id: "air-bike" },
  { name: "Treadmill Run", id: "treadmill-run" },
];
// A genuine cardio machine = the WHOLE name is a machine (so "Burpee Over Rower" is NOT one).
const MACHINE_RE = /^(bike[- ]?erg|ski[- ]?erg|rower|air[- ]?bike|assault bike|echo bike|treadmill(?: run)?|curved treadmill|stairmaster)$/i;
const WARMUP_MOBILITY_COUNT = 3;

function fixWarmup(exercises: any[], dayIndex: number, exerciseLibrary: any[]) {
  const i = exercises.findIndex((e: any) => e.isSection && /warm ?up/i.test(e.name || ""));
  if (i === -1) return exercises;

  // Find the end of the warm-up section (next section header)
  let end = exercises.findIndex((e: any, k: number) => k > i && e.isSection);
  if (end === -1) end = exercises.length;

  let items = exercises.slice(i + 1, end);

  const toArr = (v: any) => Array.isArray(v) ? v : (v ? String(v).split(/[;,]/).map((s: string) => s.trim()).filter(Boolean) : []);

  const libByName = (ex: any) => exerciseLibrary.find((le: any) => String(le.id) === String(ex?.name));
  const isCardioMachine = (ex: any) => {
    if (!ex || !ex.name || ex.isSection) return false;
    const libEx = libByName(ex);
    return !!libEx && MACHINE_RE.test(String(libEx.name).trim());
  };

  const isMobilityDrill = (ex: any) => {
    if (!ex || !ex.name || ex.isSection) return false;
    const libEx = libByName(ex);
    if (!libEx) return false;
    const mv = toArr(libEx.movementType).map((s: string) => s.toLowerCase());
    const cat = toArr(libEx.category).map((s: string) => s.toLowerCase());
    return mv.some((t: string) => ["warm up", "fire up", "mobility", "activation", "soft tissue", "potentiation", "soft-tissue"].some(k => t.includes(k)))
      || cat.some((t: string) => ["warm up", "mobility", "soft tissue", "soft-tissue", "activation"].some(k => t.includes(k)));
  };

  // (a) Strip anything that isn't a cardio machine or a mobility drill
  items = items.filter((e: any) => isCardioMachine(e) || isMobilityDrill(e));

  // (b) Ensure exactly ONE cardio machine from the palette, varied by day
  const machines = items.filter(isCardioMachine);
  const mobility = items.filter((e: any) => !isCardioMachine(e));

  // pick the day's machine, resolving to a real library exercise; fall back to ANY real machine
  const pref = CARDIO_MACHINES[((dayIndex % CARDIO_MACHINES.length) + CARDIO_MACHINES.length) % CARDIO_MACHINES.length];
  let machineEx =
    exerciseLibrary.find((le: any) => String(le.id) === pref.id) ||
    exerciseLibrary.find((le: any) => String(le.name).toLowerCase() === pref.name.toLowerCase()) ||
    exerciseLibrary.find((le: any) => MACHINE_RE.test(String(le.name).trim()));   // any genuine machine

  let machineItem: any = null;
  if (machineEx) {
    machineItem = {
      id: Date.now() + Math.random(),
      name: machineEx.id,
      timeMins: 3, timeSecs: 0, sets: 1,
      staffNotes: "3 min easy — build gently",
      trackingType: ["Time Only"],
      isSection: false,
    };
  }

  // (c) Trim mobility to exactly 3
  const trimmedMobility = mobility.slice(0, WARMUP_MOBILITY_COUNT);

  // Rebuild: 1 machine + up to 3 mobility drills
  const rebuilt = machineItem ? [machineItem, ...trimmedMobility] : trimmedMobility;
  exercises.splice(i + 1, end - (i + 1), ...rebuilt);
  return exercises;
}

// Within each Warm Up / Fire Up section, chain the exercises into a single superset.
function applyWarmupFireupSupersets(exercises: any[]) {
  if (!Array.isArray(exercises)) return exercises;
  let inGroup = false;
  for (let i = 0; i < exercises.length; i++) {
    const e = exercises[i];
    if (e.isSection) {
      const nm = String(e.name || e.sectionType || "").toLowerCase();
      inGroup = nm.includes("warm up") || nm.includes("fire up"); // matches "Warm Up/Mobility" and "Fire Up"
      continue;
    }
    if (inGroup) {
      const next = exercises[i + 1];
      // link to next only within the same section
      e.linkedToNext = !!(next && !next.isSection);
    }
  }
  return exercises;
}

const Admin = () => {
  const isStaff = localStorage.getItem("fittrack_is_staff") === "true";

  if (!isStaff) {
    return <Navigate to="/" replace />;
  }

  const [exercises, setExercises] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [wows, setWows] = useState<any[]>([]);
  const [enrichment, setEnrichment] = useState<Record<string, any>>({});

  // WOW State
  const [wowName, setWowName] = useState("");
  const [wowDesc, setWowDesc] = useState("");
  const [wowScoreType, setWowScoreType] = useState("time");
  const [wowScaledAllowed, setWowScaledAllowed] = useState(true);
  const [wowWeekStart, setWowWeekStart] = useState("");
  const [wowExercises, setWowExercises] = useState<any[]>([]);
  const [wowEditingId, setWowEditingId] = useState<string | null>(null);

  // New Exercise State
  const [newExName, setNewExName] = useState("");
  const [newExCategory, setNewExCategory] = useState<string[]>(["Strength"]);
  const [newExMuscle, setNewExMuscle] = useState("");
  const [newExEq, setNewExEq] = useState("Barbell");
  const [newExDiff, setNewExDiff] = useState("Beginner");
  const [newExVid, setNewExVid] = useState("");
  const [newExMovement, setNewExMovement] = useState<string[]>(["Push"]);
  const [newExTracking, setNewExTracking] = useState<string[]>(["Weight & Reps"]);

  const MOVEMENT_TYPES = ["Warm Up", "Knee", "Hip", "Push", "Horizontal Push", "Vertical Push", "Pull", "Horizontal Pull", "Vertical Pull", "Conditioning", "Core", "Carries", "Fire Up", "Accessory"];
  const TRACKING_TYPES = ["Weight & Reps", "Reps Only", "Time Only", "Distance & Time", "Weight & Distance", "Calories"];

  // Search State for Program Builder
  const [exerciseSearch, setExerciseSearch] = useState("");
  // Pagination for exercise library cards (render ~60, load more on demand)
  const [exCardLimit, setExCardLimit] = useState(60);

  // New Program State
  const [newProgName, setNewProgName] = useState("");
  const [newProgDesc, setNewProgDesc] = useState("");
  const [newProgStream, setNewProgStream] = useState("Foundations");
  const [newProgStartDate, setNewProgStartDate] = useState("");
  const [newProgCover, setNewProgCover] = useState("");
  const [newProgWeeks, setNewProgWeeks] = useState(4);
  const [newProgDays, setNewProgDays] = useState(5);
  const [newProgType, setNewProgType] = useState<"program" | "session_folder" | "GroupPT" | "wow">("program");
  const [progWorkouts, setProgWorkouts] = useState<any[]>([]);
  const [progWeekNotes, setProgWeekNotes] = useState<Record<number, any>>({});
  const weekLabel = (n: number) => {
    const custom = (progWeekNotes[n]?.label || "").trim();
    if (custom) return custom;
    const wc = progWeekNotes[n]?.start_date;
    if (!wc) return `Week ${n}`;
    const d = new Date(wc + 'T00:00:00');
    return `W/C ${d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}`;
  };
  const ordinal = (n: number) => {
    const s = ["th", "st", "nd", "rd"], v = n % 100;
    return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
  };
  const addDaysISO = (iso: string, n: number) => {
    const d = new Date(iso + "T00:00:00");
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  };
  const sessionDateName = (startISO: string, dayOffset: number) => {
    const d = new Date(startISO + "T00:00:00");
    if (isNaN(d.getTime())) return "";
    d.setDate(d.getDate() + dayOffset);
    const weekday = d.toLocaleDateString("en-GB", { weekday: "long" });
    const month = d.toLocaleDateString("en-GB", { month: "long" });
    return `${weekday} ${ordinal(d.getDate())} ${month}`;
  };
  const [selectedWorkoutIndex, setSelectedWorkoutIndex] = useState(0);
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [selectedDay, setSelectedDay] = useState(1);
  const [progViewMode, setProgViewMode] = useState<"day" | "full">("day");
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = e.target.files?.[0];
      if (!file) return;

      setIsUploadingImage(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('images')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage.from('images').getPublicUrl(fileName);
      setNewProgCover(data.publicUrl);
      toast.success("Image uploaded successfully!");
    } catch (error: any) {
      toast.error("Upload failed: " + error.message);
    } finally {
      setIsUploadingImage(false);
      e.target.value = '';
    }
  };

  // Integrations & Settings
  const [vimeoToken, setVimeoToken] = useState(() => localStorage.getItem("fittrack_vimeo_token") || "");
  const [anthropicKey, setAnthropicKey] = useState(() => getAnthropicKey());
  const [isSyncing, setIsSyncing] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);

  // Edit Exercise State
  const [editingExercise, setEditingExercise] = useState<any | null>(null);
  const [librarySearch, setLibrarySearch] = useState("");
  const [catF, setCatF] = useState("All");
  const [muscleF, setMuscleF] = useState("All");
  const [moveF, setMoveF] = useState("All");
  const [equipF, setEquipF] = useState("All");
  const [diffF, setDiffF] = useState("All");
  const [trackF, setTrackF] = useState("All");

  // Members State
  const [activeTab, setActiveTab] = useState("exercises");

  // Nutrition section flags
  const [appFlags, setAppFlags] = useState<any>(null);
  useEffect(() => { getAppSettings().then(setAppFlags); }, []);
  const toggleFlag = async (flag: string, value: boolean) => {
    const { error } = await saveAppSettings({ [flag]: value });
    if (error) { toast.error("Couldn't save setting"); return; }
    setAppFlags((prev: any) => ({ ...prev, [flag]: value }));
    toast.success(value ? "Section enabled" : "Section hidden");
  };

  const [members, setMembers] = useState<any[]>([]);
  const [selectedMember, setSelectedMember] = useState<any | null>(null);
  const [memberActivity, setMemberActivity] = useState<any[]>([]);
  const [isLoadingActivity, setIsLoadingActivity] = useState(false);
  const [inviteName, setInviteName] = useState("");
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteAllowed, setInviteAllowed] = useState<string[]>(["Foundations", "Stronger", "Fusion", "Performance", "Group PT"]);
  const [isInviting, setIsInviting] = useState(false);
  const [isBulkInviting, setIsBulkInviting] = useState(false);

  // Notification State
  const [nutritionMembers, setNutritionMembers] = useState<any[]>([]);
  const [nutritionHabits, setNutritionHabits] = useState<any[]>([]);
  const [nutritionSearch, setNutritionSearch] = useState("");
  const [nutritionFilter, setNutritionFilter] = useState<"all" | "attention" | "coached">("all");
  const [notifTitle, setNotifTitle] = useState("");
  const [notifMessage, setNotifMessage] = useState("");
  const [isSendingNotif, setIsSendingNotif] = useState(false);
  const [nutritionSubView, setNutritionSubView] = useState<"coaching" | "library">("coaching");
  const [habitLibrary, setHabitLibrary] = useState<any[]>([]);
  const [isUpdatingHabit, setIsUpdatingHabit] = useState<number | null>(null);

  // Export State
  const [isZipping, setIsZipping] = useState(false);

  // Calendar State
  // Calendar State
  const [scheduledEvents, setScheduledEvents] = useState<any[]>(() => {
    const saved = localStorage.getItem('fittrack_scheduled_events');
    return saved ? JSON.parse(saved) : [];
  });
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [scheduleProgramId, setScheduleProgramId] = useState('');
  const [scheduleWorkoutId, setScheduleWorkoutId] = useState('');

  const saveScheduledEvents = (events: any[]) => {
    setScheduledEvents(events);
    localStorage.setItem('fittrack_scheduled_events', JSON.stringify(events));
  };

  // TV Display State
  const [displayPresets, setDisplayPresets] = useState<any[]>(() => {
    const saved = localStorage.getItem('fittrack_display_presets');
    return saved ? JSON.parse(saved) : [{
      id: 'default',
      name: 'Default Preset',
      layout: { orientation: 'landscape', showRest: true, showHeaders: true, showDuration: true, showWeek: true, showNumbers: true },
      colors: { background: '#000000', blockBackground: '#1a1a1a', opacity: 100 },
      typography: { fontSize: 'medium' },
      media: { url: '', type: 'image' }
    }];
  });
  const [selectedPresetId, setSelectedPresetId] = useState('default');
  const [editingPresetId, setEditingPresetId] = useState<string | null>(null);
  const [selectedDisplayProgramId, setSelectedDisplayProgramId] = useState<string>('');
  const [selectedDisplayWorkoutId, setSelectedDisplayWorkoutId] = useState<string>('');

  const savePresets = (presets: any[]) => {
    setDisplayPresets(presets);
    localStorage.setItem('fittrack_display_presets', JSON.stringify(presets));
  };

  const staffSecret = import.meta.env.VITE_STAFF_SECRET || "42a37f4a3f9ceed78d7928187bfc339d25af43d79d5fb0b0";

  const loadMembers = async () => {
    try {
      const data = await manageMembers({ action: "list", staffSecret });
      if (data?.members) {
        setMembers(data.members);
      }
    } catch (e) {
      console.error("Failed to load members", e);
    }
  };

  const loadNutritionMembers = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("manage-nutrition", { body: { action: "list", staffSecret } });
      if (error) throw new Error(error.message);
      if (data?.error) throw new Error(data.error);
      if (data?.members) setNutritionMembers(data.members);
    } catch (e) {
      console.error("Failed to load nutrition members", e);
    }
  };

  const loadHabitLibrary = async () => {
    try {
      const data = await manageNutrition({ action: "listHabits" });
      if (data?.habits) setHabitLibrary(data.habits);
    } catch (e) {
      console.error("Failed to load habit library", e);
    }
  };

  const handleUpdateHabit = async (habitId: number, updates: any) => {
    setIsUpdatingHabit(habitId);
    try {
      await manageNutrition({ action: "updateHabit", habitId, ...updates });
      toast.success("Habit updated");
      loadHabitLibrary();
    } catch (e: any) {
      toast.error(`Failed: ${e.message}`);
    } finally {
      setIsUpdatingHabit(null);
    }
  };

  // Track which lazy data has been loaded so we don't refetch (ref avoids stale closures)
  const loadedTabsRef = useRef<Set<string>>(new Set());
  const ensureTabData = useCallback((tab: string) => {
    if (loadedTabsRef.current.has(tab)) return;
    loadedTabsRef.current.add(tab);
    if (tab === "members") loadMembers();
    if (tab === "nutrition") { loadNutritionMembers(); loadHabitLibrary(); getHabits().then(setNutritionHabits); }
  }, []);

  useEffect(() => {
    const handleSync = async () => {
      setExercises(await getExercises());
      setPrograms(await getPrograms());
      setWows(await getWorkoutsOfWeek());
      setEnrichment(await getExerciseEnrichment());
    };

    handleSync();
    // Load data for the initially-active tab
    ensureTabData(activeTab);

    window.addEventListener('fittrack_synced', handleSync);
    return () => window.removeEventListener('fittrack_synced', handleSync);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const manageMembers = async (body: any) => {
    const { data, error } = await supabase.functions.invoke("manage-members", { body });
    if (error) throw new Error(error.message);
    if (data?.error) throw new Error(data.error);
    return data;
  };

  const manageNutrition = async (body: any) => {
    const { data, error } = await supabase.functions.invoke("manage-nutrition", { body: { ...body, staffSecret } });
    if (error) throw new Error(error.message);
    if (data?.error) throw new Error(data.error);
    return data;
  };

  const handleSetNextHabit = async (memberId: string, habitId: number) => {
    try {
      await manageNutrition({ action: "setNextHabit", memberId, habitId });
      toast.success("Next habit updated");
      loadNutritionMembers();
    } catch (e: any) {
      toast.error(`Failed: ${e.message}`);
    }
  };

  const handleAddCoachNote = async (memberId: string, habitId: number | undefined, note: string) => {
    try {
      await manageNutrition({ action: "addNote", memberId, habitId, note });
      toast.success("Note added");
      loadNutritionMembers();
    } catch (e: any) {
      toast.error(`Failed: ${e.message}`);
    }
  };

  const handleSetCoached = async (memberId: string, coached: boolean) => {
    try {
      await manageNutrition({ action: "setCoached", memberId, coached });
      toast.success(coached ? "Marked as coached" : "Un-coached");
      loadNutritionMembers();
    } catch (e: any) {
      toast.error(`Failed: ${e.message}`);
    }
  };

  const handleSetMacros = async (memberId: string, macros: any) => {
    try {
      await manageNutrition({ action: "setMacros", memberId, ...macros });
      toast.success("Macros updated");
      loadNutritionMembers();
    } catch (e: any) {
      toast.error(`Failed: ${e.message}`);
    }
  };

  const handleSetAccess = async (memberId: string, acc: string, checked: boolean) => {
    const member = members.find(m => m.id === memberId);
    if (!member) return;

    const allowed = member.allowed_access || [];
    const nextAllowedArray = checked ? [...allowed, acc] : allowed.filter((a: string) => a !== acc);
    
    // Optimistic update
    setMembers(members.map(m => m.id === memberId ? { ...m, allowed_access: nextAllowedArray } : m));
    
    const toastId = toast.loading(`Updating ${member.full_name}'s access...`);
    
    try {
      await manageMembers({ action: "setAccess", memberId, allowed: nextAllowedArray, staffSecret });
      toast.success("Access updated", { id: toastId });
    } catch (e: any) {
      console.error("setAccess error:", e);
      toast.error(`Failed to update access: ${e.message}`, { id: toastId });
      await loadMembers(); // revert
    }
  };

  const handleInvite = async () => {
    if (!inviteName || !inviteEmail) return;
    setIsInviting(true);
    try {
      await manageMembers({ 
        action: "invite", 
        name: inviteName, 
        email: inviteEmail, 
        allowed: inviteAllowed, 
        staffSecret
      });
      toast.success("Member invited");
      setInviteName("");
      setInviteEmail("");
      await loadMembers();
    } catch (e: any) {
      console.error("Invite error:", e);
      toast.error(`Failed to invite member: ${e.message}`, { duration: 8000 });
    } finally {
      setIsInviting(false);
    }
  };

  const handleBulkInvite = async (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsBulkInviting(true);
    try {
      const text = await file.text();
      const rows = text.split('\n').map((r: string) => r.split(','));
      const headers = rows[0].map((h: string) => h.trim().toLowerCase());
      const nameIdx = headers.indexOf('name');
      const emailIdx = headers.indexOf('email');
      const accessIdx = headers.indexOf('access');
      
      if (nameIdx === -1 || emailIdx === -1) {
        throw new Error("CSV must have 'name' and 'email' columns");
      }
      
      const newMembers = rows.slice(1).filter((r: string[]) => r.length > Math.max(nameIdx, emailIdx) && r[emailIdx]).map((r: string[]) => {
        let allowed = ["Foundations", "Stronger", "Fusion", "Performance", "Group PT"];
        if (accessIdx !== -1 && r[accessIdx]) {
          allowed = r[accessIdx].split(';').map(s => s.trim()).filter(Boolean);
        }
        return { name: r[nameIdx].trim(), email: r[emailIdx].trim(), allowed };
      });
      
      const data = await manageMembers({ 
        action: "bulkInvite", 
        members: newMembers, 
        staffSecret
      });
      
      toast.success(`Bulk invite complete. Invited: ${data.invited?.length || 0}, Failed: ${data.failed?.length || 0}`);
      loadMembers();
    } catch (err: any) {
      toast.error(`Bulk invite failed: ${err.message}`);
    } finally {
      setIsBulkInviting(false);
      e.target.value = '';
    }
  };
  
  const handleViewActivity = async (member: any) => {
    setSelectedMember(member);
    setIsLoadingActivity(true);
    const activity = await getMemberActivity(member.id);
    setMemberActivity(activity);
    setIsLoadingActivity(false);
  };

  const handleSyncVimeo = async () => {
    if (!vimeoToken) return;
    setIsSyncing(true);
    try {
      let addedCount = 0;
      const currentExercises = [...exercises];
      let page = 1;
      let hasMore = true;

      while (hasMore) {
        const response = await fetch(`https://api.vimeo.com/me/videos?per_page=100&page=${page}`, {
          headers: {
            "Authorization": `Bearer ${vimeoToken}`,
            "Content-Type": "application/json",
            "Accept": "application/vnd.vimeo.*+json;version=3.4"
          }
        });
        
        if (!response.ok) {
          throw new Error("Failed to fetch videos. Check your token.");
        }
        
        const data = await response.json();
        const vimeoVideos = data.data || [];
        
        if (vimeoVideos.length === 0) {
          hasMore = false;
          break;
        }
        
        vimeoVideos.forEach((video: any) => {
          const name = video.name;
          const link = video.link;
          const id = name.toLowerCase().replace(/\s+/g, '-');
          
          if (!currentExercises.find(e => e.id === id)) {
            currentExercises.push({
              id,
              name,
              category: ["Strength"],
              muscle: "Uncategorized",
              equipment: "Bodyweight",
              difficulty: "Beginner",
              videoUrl: link,
              movementType: ["Push"]
            });
            addedCount++;
          }
        });
        
        if (data.paging && data.paging.next) {
          page++;
        } else {
          hasMore = false;
        }
      }
      
      if (addedCount > 0) {
        setExercises(currentExercises);
        saveExercises(currentExercises);
        toast.success(`Successfully synced ${addedCount} new videos as exercises!`);
      } else {
        toast.info("No new videos found to sync.");
      }
    } catch (error: any) {
      toast.error(error.message || "Error syncing with Vimeo");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleAddExercise = () => {
    if (!newExName || !newExMuscle) {
      toast.error("Please fill out name and muscle group.");
      return;
    }
    const newEx = {
      id: newExName.toLowerCase().replace(/\s+/g, '-'),
      name: newExName,
      category: newExCategory,
      muscle: newExMuscle,
      equipment: newExEq,
      difficulty: newExDiff,
      videoUrl: newExVid,
      movementType: newExMovement,
      trackingType: newExTracking,
    };
    const updated = [...exercises, newEx];
    setExercises(updated);
    saveExercises(updated).then(r => {
      if (r.success) toast.success("Exercise added!");
      else toast.warning("Exercise saved locally — cloud sync failed");
    });
    setNewExName("");
    setNewExMuscle("");
    setNewExVid("");
    setNewExTracking(["Weight & Reps"]);
  };

  const handleDeleteExercise = (id: string) => {
    const updated = exercises.filter(e => e.id !== id);
    setExercises(updated);
    saveExercises(updated).then(r => {
      if (r.success) toast.success("Exercise deleted!");
      else toast.warning("Deleted locally — cloud sync failed");
    });
  };

  const handleUpdateExercise = () => {
    if (!editingExercise) return;
    const updated = exercises.map(e => e.id === editingExercise.id ? editingExercise : e);
    setExercises(updated);
    saveExercises(updated).then(r => {
      if (!r.success) toast.warning("Updated locally — cloud sync failed");
      else toast.success("Exercise updated!");
    });
    setEditingExercise(null);
  };

  const toArr = (v: any) => Array.isArray(v) ? v : (v == null ? [] : String(v).split(/[;,]/).map(s => s.trim()).filter(Boolean));
  const uniq  = (vals: string[]) => ["All", ...Array.from(new Set(vals)).filter(Boolean).sort()];

  const filteredLibrary = useMemo(() => exercises.filter(ex => {
    const n = ex.name?.toLowerCase() || "";
    return n.includes(librarySearch.toLowerCase())
      && (catF === "All" || toArr(ex.category).includes(catF))
      && (muscleF === "All" || ex.muscle === muscleF)
      && (moveF === "All" || toArr(ex.movementType).includes(moveF))
      && (equipF === "All" || ex.equipment === equipF)
      && (diffF === "All" || ex.difficulty === diffF)
      && (trackF === "All" || toArr(ex.trackingType).includes(trackF));
  }), [exercises, librarySearch, catF, muscleF, moveF, equipF, diffF, trackF]);

  // Reset pagination when filters change
  useEffect(() => { setExCardLimit(60); }, [librarySearch, catF, muscleF, moveF, equipF, diffF, trackF]);

  const catOpts    = useMemo(() => uniq(exercises.flatMap(ex => toArr(ex.category))), [exercises]);
  const muscleOpts = useMemo(() => uniq(exercises.map(ex => ex.muscle)), [exercises]);
  const moveOpts   = useMemo(() => uniq(exercises.flatMap(ex => toArr(ex.movementType))), [exercises]);
  const equipOpts  = useMemo(() => uniq(exercises.map(ex => ex.equipment)), [exercises]);
  const diffOpts   = useMemo(() => uniq(exercises.map(ex => ex.difficulty)), [exercises]);
  const trackOpts  = useMemo(() => uniq(exercises.flatMap(ex => toArr(ex.trackingType))), [exercises]);

  const handleBulkDelete = () => {
    if (!librarySearch && catF === "All" && muscleF === "All" && moveF === "All" && equipF === "All" && diffF === "All" && trackF === "All") return;
    if (filteredLibrary.length === 0) return;
    
    const idsToDelete = filteredLibrary.map(e => e.id);
    const updated = exercises.filter(e => !idsToDelete.includes(e.id));
    setExercises(updated);
    saveExercises(updated).then(r => {
      if (r.success) toast.success(`Deleted ${filteredLibrary.length} exercises!`);
      else toast.warning(`Deleted locally — cloud sync failed`);
    });
    setLibrarySearch("");
    setCatF("All");
    setMuscleF("All");
    setMoveF("All");
    setEquipF("All");
    setDiffF("All");
    setTrackF("All");
  };

  const handleExportData = () => {
    try {
      if (exercises.length === 0) {
        toast.error("No exercises to export.");
        return;
      }
      
      const headers = ["ID", "Name", "Categories", "Muscle", "Equipment", "Difficulty", "Movement Types", "Video URL", "Tracking Style"];
      const csvRows = [headers.join(",")];
      
      exercises.forEach(ex => {
        const row = [
          `"${ex.id || ""}"`,
          `"${ex.name || ""}"`,
          `"${Array.isArray(ex.category) ? ex.category.join("; ") : (ex.category || "")}"`,
          `"${ex.muscle || ""}"`,
          `"${ex.equipment || ""}"`,
          `"${ex.difficulty || ""}"`,
          `"${Array.isArray(ex.movementType) ? ex.movementType.join("; ") : (ex.movementType || "")}"`,
          `"${ex.videoUrl || ""}"`,
          `"${Array.isArray(ex.trackingType) ? ex.trackingType.join("; ") : (ex.trackingType || "Weight & Reps")}"`
        ];
        csvRows.push(row.join(","));
      });
      
      const csvString = csvRows.join("\n");
      
      navigator.clipboard.writeText(csvString).catch(() => {});

      const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "fittrack_exercises_backup.csv";
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success("Exercises backed up! (Also copied to clipboard just in case)");
    } catch (error) {
      toast.error("Failed to export backup.");
    }
  };

  const handleExportProgramsData = () => {
    try {
      if (programs.length === 0) {
        toast.error("No programs to export.");
        return;
      }
      
      const jsonString = JSON.stringify(programs, null, 2);
      
      navigator.clipboard.writeText(jsonString).catch(() => {});

      const blob = new Blob([jsonString], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "fittrack_programs_backup.json";
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success("Programs backed up! (Also copied to clipboard just in case)");
    } catch (error) {
      toast.error("Failed to export programs backup.");
    }
  };

  const handleGenerateWorkoutSlots = () => {
    if (newProgType === "session_folder") {
      setProgWorkouts([{
        id: `w_${Date.now()}_0`,
        name: `Session 1`,
        exercises: []
      }]);
    } else {
      const weeks = newProgType === "GroupPT" ? 12 : newProgWeeks;
      const days = newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays;
      const totalWorkouts = weeks * days;
      const newWorkouts = [];
      for (let i = 0; i < totalWorkouts; i++) {
        const week = Math.floor(i / days) + 1;
        const day = (i % days) + 1;
        newWorkouts.push({
          id: `w_${Date.now()}_${i}`,
          name: `Day ${day}`,
          week,
          day,
          exercises: []
        });
      }
      setProgWorkouts(newWorkouts);
    }
    setSelectedWorkoutIndex(0);
    setSelectedWeek(1);
  };

  const handleAddSession = () => {
    const updatedWorkouts = [...progWorkouts];
    updatedWorkouts.push({
      id: `w_${Date.now()}_${updatedWorkouts.length}`,
      name: `Session ${updatedWorkouts.length + 1}`,
      exercises: []
    });
    setProgWorkouts(updatedWorkouts);
    setSelectedWorkoutIndex(updatedWorkouts.length - 1);
  };

  const handleAddProgExercise = () => {
    const updatedWorkouts = [...progWorkouts];
    updatedWorkouts[selectedWorkoutIndex] = {
      ...updatedWorkouts[selectedWorkoutIndex],
      exercises: [
        ...updatedWorkouts[selectedWorkoutIndex].exercises,
        { id: Date.now(), blockType: "Strength", name: "", sets: 3, reps: 10, weight: 0, rest: 0, linkedToNext: false, eachSide: false, coachingNotes: "" }
      ]
    };
    setProgWorkouts(updatedWorkouts);
  };

  const handleAddProgSection = (type: string = "Normal") => {
    const updatedWorkouts = [...progWorkouts];
    let name = type === "Normal" ? "New Section" : `${type} Block`;
    let description = "";
    if (type === "AI Engine") {
      name = "AI Engine Builder";
      description = "30-60 min scalable cardio focus";
    }
    updatedWorkouts[selectedWorkoutIndex] = {
      ...updatedWorkouts[selectedWorkoutIndex],
      exercises: [
        ...updatedWorkouts[selectedWorkoutIndex].exercises,
        { id: Date.now(), isSection: true, name, description, sectionType: type }
      ]
    };
    setProgWorkouts(updatedWorkouts);
  };

  const handleRemoveProgExercise = (id: number | string) => {
    const updatedWorkouts = [...progWorkouts];
    updatedWorkouts[selectedWorkoutIndex] = {
      ...updatedWorkouts[selectedWorkoutIndex],
      exercises: updatedWorkouts[selectedWorkoutIndex].exercises.filter((e: any) => String(e.id) !== String(id))
    };
    setProgWorkouts(updatedWorkouts);
  };

  const updateProgExercise = (id: number | string, field: string, val: any) => {
    const updatedWorkouts = [...progWorkouts];
    updatedWorkouts[selectedWorkoutIndex] = {
      ...updatedWorkouts[selectedWorkoutIndex],
      exercises: updatedWorkouts[selectedWorkoutIndex].exercises.map((e: any) => String(e.id) === String(id) ? { ...e, [field]: val } : e)
    };
    setProgWorkouts(updatedWorkouts);
  };

  const onDragEnd = (result: any) => {
    if (!result.destination) return;
    const updatedWorkouts = [...progWorkouts];
    const items = Array.from(updatedWorkouts[selectedWorkoutIndex].exercises);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    updatedWorkouts[selectedWorkoutIndex] = {
      ...updatedWorkouts[selectedWorkoutIndex],
      exercises: items
    };
    setProgWorkouts(updatedWorkouts);
  };

  const handleCopyFromPrevious = () => {
    if (selectedWorkoutIndex === 0) return;
    const updatedWorkouts = [...progWorkouts];
    const previousExercises = JSON.parse(JSON.stringify(updatedWorkouts[selectedWorkoutIndex - 1].exercises));
    const newExercises = previousExercises.map((e: any) => ({ ...e, id: Date.now() + Math.random() }));
    updatedWorkouts[selectedWorkoutIndex] = {
      ...updatedWorkouts[selectedWorkoutIndex],
      exercises: newExercises
    };
    setProgWorkouts(updatedWorkouts);
    toast.success("Copied exercises from previous workout!");
  };

  const handleDuplicateDayTo = (targetWeek: number, targetDay: number) => {
    const updatedWorkouts = [...progWorkouts];
    const currentExercises = JSON.parse(JSON.stringify(updatedWorkouts[selectedWorkoutIndex].exercises));
    const newExercises = currentExercises.map((e: any) => ({ ...e, id: Date.now() + Math.random() }));
    
    const targetIdx = updatedWorkouts.findIndex(w => w.week === targetWeek && w.day === targetDay);
    if (targetIdx >= 0) {
      updatedWorkouts[targetIdx] = {
        ...updatedWorkouts[targetIdx],
        exercises: newExercises
      };
      setProgWorkouts(updatedWorkouts);
      toast.success(`Copied to Week ${targetWeek}, Day ${targetDay}!`);
    }
  };

  const handleCopyWeekFromPrevious = () => {
    if (selectedWeek <= 1) return;
    const updatedWorkouts = [...progWorkouts];
    
    const daysToCopy = newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays;
    for (let d = 1; d <= daysToCopy; d++) {
      const sourceIdx = updatedWorkouts.findIndex(w => w.week === selectedWeek - 1 && w.day === d);
      const targetIdx = updatedWorkouts.findIndex(w => w.week === selectedWeek && w.day === d);
      
      if (sourceIdx >= 0 && targetIdx >= 0) {
        const sourceExercises = JSON.parse(JSON.stringify(updatedWorkouts[sourceIdx].exercises));
        updatedWorkouts[targetIdx] = { ...updatedWorkouts[targetIdx], exercises: sourceExercises.map((e: any) => ({ ...e, id: Date.now() + Math.random() })) };
      }
    }
    
    setProgWorkouts(updatedWorkouts);
    toast.success(`Copied all days from Week ${selectedWeek - 1}!`);
  };

  const handleDuplicateWeekTo = (targetWeek: number) => {
    const maxWeeks = newProgType === "GroupPT" ? 12 : newProgWeeks;
    if (targetWeek === selectedWeek || targetWeek < 1 || targetWeek > maxWeeks) return;
    const updatedWorkouts = [...progWorkouts];
    
    const daysToDup = newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays;
    for (let d = 1; d <= daysToDup; d++) {
      const sourceIdx = updatedWorkouts.findIndex(w => w.week === selectedWeek && w.day === d);
      const targetIdx = updatedWorkouts.findIndex(w => w.week === selectedWeek && w.day === d);
      
      if (sourceIdx >= 0 && targetIdx >= 0) {
        const sourceExercises = JSON.parse(JSON.stringify(updatedWorkouts[sourceIdx].exercises));
        updatedWorkouts[targetIdx] = { ...updatedWorkouts[targetIdx], exercises: sourceExercises.map((e: any) => ({ ...e, id: Date.now() + Math.random() })) };
      }
    }
    
    setProgWorkouts(updatedWorkouts);
    toast.success(`Copied Week ${selectedWeek} to Week ${targetWeek}!`);
  };

  // ── Rules-based shuffle pool (enrichment alternates first, then tightened fallback) ──
  const norm = (s: string) => String(s || "").toLowerCase().trim();
  const mt = (e: any) => Array.isArray(e?.movementType) ? e.movementType : String(e?.movementType || "").split(/[;,]/).map((s: string) => s.trim()).filter(Boolean);
  const byName = useMemo(() => {
    const m: Record<string, any> = {}; exercises.forEach(e => { m[norm(e.name)] = e; }); return m;
  }, [exercises]);
  // O(1) exercise lookup by id — replaces repeated .find() calls in render loops
  const exById = useMemo(() => {
    const m: Record<string, any> = {}; exercises.forEach(e => { m[String(e.id)] = e; }); return m;
  }, [exercises]);
  // Pre-sorted exercise list for the picker dropdowns (avoids re-sorting on every render)
  const sortedExercises = useMemo(() => [...exercises].sort((a, b) => a.name.localeCompare(b.name)), [exercises]);
  const STRENGTH_TAGS = ["Push","Horizontal Push","Vertical Push","Pull","Horizontal Pull","Vertical Pull","Knee","Hip","Core","Carries","Accessory"];
  const isStrengthMove = (e: any) => mt(e).some((t: string) => STRENGTH_TAGS.includes(t));

  function rulesBasedPool(libEx: any): any[] {
    const row = enrichment[String(libEx.id)];
    // (a) coach-picked enrichment alternates — resolve names to real library exercises
    if (row) {
      const cols = ["alt_same_pattern","alt_equipment","alt_progress","alt_regress","alt_joint_friendly","alt_home"];
      const seen = new Set<string>([String(libEx.id)]);
      const alts: any[] = [];
      for (const c of cols) {
        String(row[c] || "").split(/[,/]| or /i).map(norm).filter(Boolean).forEach(tok => {
          const ex = byName[tok];
          if (ex && !seen.has(String(ex.id))) { seen.add(String(ex.id)); alts.push(ex); }
        });
      }
      if (alts.length) return alts;
    }
    // (b) fallback: same SPECIFIC movement pattern (incl H/V direction) + same muscle, then relax
    const libTags = mt(libEx);
    const specific = libTags.find((t: string) => /Horizontal|Vertical/.test(t)) || libTags[0];
    if (specific) {
      const origIsStrength = isStrengthMove(libEx);
      const sameMuscle = exercises.filter(e => e.id !== libEx.id && mt(e).includes(specific) && e.muscle === libEx.muscle && isStrengthMove(e) === origIsStrength);
      if (sameMuscle.length) return sameMuscle;
      const samePattern = exercises.filter(e => e.id !== libEx.id && mt(e).includes(specific) && isStrengthMove(e) === origIsStrength);
      if (samePattern.length) return samePattern;
    }
    return [];
  }

  const handleShuffleExercise = (exerciseId: number | string) => {
    const updatedWorkouts = [...progWorkouts];
    const currentEx = updatedWorkouts[selectedWorkoutIndex].exercises.find((e: any) => String(e.id) === String(exerciseId));
    if (!currentEx || !currentEx.name) return;
    
    const libEx = exById[String(currentEx.name)];
    if (!libEx) return;
    
    const pool = rulesBasedPool(libEx);
    
    if (pool.length > 0) {
      const randomEx = pool[Math.floor(Math.random() * pool.length)];
      updatedWorkouts[selectedWorkoutIndex] = {
        ...updatedWorkouts[selectedWorkoutIndex],
        exercises: updatedWorkouts[selectedWorkoutIndex].exercises.map((e: any) => String(e.id) === String(exerciseId) ? { ...e, name: randomEx.id } : e)
      };
      setProgWorkouts(updatedWorkouts);
      toast.success(`Swapped for ${randomEx.name}`);
    } else {
      toast.error("No matching exercises found to swap with.");
    }
  };

  const handleApplyToWeek = (exerciseId: number | string) => {
    const currentEx = progWorkouts[selectedWorkoutIndex].exercises.find((e: any) => String(e.id) === String(exerciseId));
    if (!currentEx) return;

    const updatedWorkouts = [...progWorkouts];
    let appliedCount = 0;
    
    const daysToApply = newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays;
    for (let d = 1; d <= daysToApply; d++) {
      if (d === selectedDay) continue;
      const targetIdx = updatedWorkouts.findIndex(w => w.week === selectedWeek && w.day === d);
      if (targetIdx >= 0) {
        const exIndex = updatedWorkouts[selectedWorkoutIndex].exercises.findIndex((e: any) => String(e.id) === String(exerciseId));
        if (updatedWorkouts[targetIdx].exercises[exIndex]) {
          const targetEx = updatedWorkouts[targetIdx].exercises[exIndex];
          if (!targetEx.isSection) {
            updatedWorkouts[targetIdx] = {
              ...updatedWorkouts[targetIdx],
              exercises: updatedWorkouts[targetIdx].exercises.map((e: any, i: number) => i === exIndex ? {
                ...e,
                sets: currentEx.sets,
                reps: currentEx.reps,
                distance: currentEx.distance,
                timeMins: currentEx.timeMins,
                timeSecs: currentEx.timeSecs,
                rest: currentEx.rest
              } : e)
            };
            appliedCount++;
          }
        }
      }
    }
    
    setProgWorkouts(updatedWorkouts);
    toast.success(`Applied settings to ${appliedCount} other days this week!`);
  };

  const handleShuffleAll = () => {
    const updatedWorkouts = [...progWorkouts];
    let shuffledCount = 0;
    
    updatedWorkouts[selectedWorkoutIndex].exercises.forEach((currentEx: any) => {
      if (currentEx.isSection || !currentEx.name) return;
      
      const libEx = exById[String(currentEx.name)];
      if (!libEx) return;
      
      const pool = rulesBasedPool(libEx);
      
      if (pool.length > 0) {
        const randomEx = pool[Math.floor(Math.random() * pool.length)];
        currentEx.name = randomEx.id;
        shuffledCount++;
      }
    });
    
    setProgWorkouts(updatedWorkouts);
    if (shuffledCount > 0) {
      toast.success(`Shuffled ${shuffledCount} exercises!`);
    } else {
      toast.error("No exercises could be shuffled.");
    }
  };

  const handleGenerateEngineWorkout = async (sectionId: number) => {
    if (!anthropicKey) {
      toast.error("Please add your Anthropic API Key in the Settings tab first.");
      return;
    }

    const updatedWorkouts = [...progWorkouts];
    const currentWorkout = updatedWorkouts[selectedWorkoutIndex];
    const sectionIndex = currentWorkout.exercises.findIndex((e: any) => e.id === sectionId);

    if (sectionIndex === -1) return;

    setIsGeneratingAI(true);
    const toastId = toast.loading("AI is analyzing your library and building a 40-min engine workout...");

    try {
      const exList = exercises.map(ex => `- ${ex.name} (ID: ${ex.id}, Category: ${Array.isArray(ex.category) ? ex.category.join(',') : ex.category}, Movement: ${Array.isArray(ex.movementType) ? ex.movementType.join(',') : ex.movementType})`).join('\n');

      const prompt = `You are an expert fitness coach. Create a 40-minute scalable engine (cardio/conditioning) workout using ONLY the following available exercises:

${exList}

The workout must be a 40-minute EMOM (Every Minute on the Minute) or AMRAP style, utilizing 4 to 6 different exercises.

Return ONLY a valid JSON array of exercise objects to be inserted into the workout. Each object must follow this exact structure:
[
  {
    "blockType": "Cardio",
    "name": "exercise_id_from_list",
    "sets": 10,
    "reps": 15,
    "weight": 0,
    "distance": 0,
    "timeMins": 1,
    "timeSecs": 0,
    "rest": 0,
    "linkedToNext": false,
    "eachSide": false,
    "staffNotes": "Brief coaching note"
  }
]
Do not include any markdown formatting, backticks, or other text outside the JSON array.`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "x-api-key": anthropicKey,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-3-haiku-20240307",
          max_tokens: 1500,
          messages: [{ role: "user", content: prompt }]
        })
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error?.message || "Failed to generate workout");
      }

      const data = await response.json();
      let text = data.content[0].text.trim();
      
      if (text.startsWith('```json')) text = text.replace(/```json\n?/, '');
      if (text.startsWith('```')) text = text.replace(/```\n?/, '');
      if (text.endsWith('```')) text = text.replace(/```$/, '');
      
      const newExercises = JSON.parse(text).map((ex: any, i: number) => ({
        ...ex,
        id: Date.now() + i + Math.random(),
      }));

      currentWorkout.exercises[sectionIndex].name = "AI Engine: 40 Min EMOM";
      currentWorkout.exercises[sectionIndex].sectionType = "EMOM";
      currentWorkout.exercises[sectionIndex].description = "AI Generated 40-Min Engine Block";

      currentWorkout.exercises.splice(sectionIndex + 1, 0, ...newExercises);

      setProgWorkouts(updatedWorkouts);
      toast.success("40-Min Engine Workout generated successfully!", { id: toastId });
    } catch (error: any) {
      console.error(error);
      toast.error("AI Generation failed: " + error.message, { id: toastId });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const [editingProgramId, setEditingProgramId] = useState<string | null>(null);

  const handleAddProgram = () => {
    if (!newProgName) {
      toast.error("Please provide a program name.");
      return;
    }
    const week1Start = progWeekNotes[1]?.start_date || newProgStartDate || null;
    if (newProgType === "wow") {
      const wow = {
        id: editingProgramId || `wow_${Date.now()}`,
        name: newProgName,
        description: newProgDesc,
        score_type: wowScoreType,
        scaled_allowed: wowScaledAllowed,
        week_start: wowWeekStart,
        exercises: progWorkouts[0]?.exercises?.map((e: any) => ({
          isSection: e.isSection, sectionType: e.sectionType || "Normal", description: e.description, blockType: e.blockType || "Strength", name: e.name, sets: e.sets, reps: e.reps, weight: e.weight, distance: e.distance, timeMins: e.timeMins, timeSecs: e.timeSecs, rest: e.rest || 0, linkedToNext: e.linkedToNext, eachSide: e.eachSide, staffNotes: e.staffNotes, coachingNotes: e.coachingNotes
        })) || []
      };
      saveWorkoutOfWeek(wow).then(async (r) => {
        if (r.success) {
          toast.success(editingProgramId ? "WOW updated!" : "WOW created!");
          setWows(await getWorkoutsOfWeek());
          setEditingProgramId(null);
          setNewProgName("");
          setNewProgDesc("");
          setProgWorkouts([]);
          setActiveTab("wow");
        } else {
          toast.error("Failed to save WOW: " + r.error?.message);
        }
      });
    } else {
      const newProg = {
        id: editingProgramId || "p_" + Date.now(),
        name: newProgName,
        description: newProgDesc,
        stream: newProgStream,
        start_date: week1Start,
        coverImage: newProgCover,
        type: newProgType,
        weeks: newProgType === "GroupPT" ? 12 : newProgWeeks,
        daysPerWeek: newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays,
        weekNotes: progWeekNotes,
        workouts: progWorkouts.map(w => {
          const exercises = w.exercises.map((e: any) => ({ isSection: e.isSection, sectionType: e.sectionType || "Normal", description: e.description, blockType: e.blockType || "Strength", name: e.name, sets: e.sets, reps: e.reps, weight: e.weight, distance: e.distance, timeMins: e.timeMins, timeSecs: e.timeSecs, rest: e.rest || 0, linkedToNext: e.linkedToNext, eachSide: e.eachSide, staffNotes: e.staffNotes, coachingNotes: e.coachingNotes }));
          applyWarmupFireupSupersets(exercises);
          return {
            name: w.name,
            week: w.week,
            day: w.day,
            minDays: w.minDays,
            dayCounts: w.dayCounts,
            date: w.date,
            exercises
          };
        })
      };
      
      let updated;
      if (editingProgramId) {
        updated = programs.map(p => p.id === editingProgramId ? newProg : p);
      } else {
        updated = [...programs, newProg];
      }
      
      setPrograms(updated);
      const isEdit = !!editingProgramId;
      savePrograms(updated).then(r => {
        if (r.success) toast.success(isEdit ? "Program updated!" : "Program added!");
        else toast.warning("Saved locally — cloud sync failed. It will retry automatically.");
      });
    }
    
    setNewProgName("");
    setNewProgDesc("");
    setNewProgStream("Foundations");
    setNewProgStartDate("");
    setNewProgDays(5);
    setNewProgCover("");
    setProgWorkouts([]);
    setProgWeekNotes({});
    setEditingProgramId(null);
  };

  const handleEditProgram = (prog: any) => {
    setEditingProgramId(prog.id);
    setNewProgName(prog.name);
    setNewProgDesc(prog.description || "");
    setNewProgStream(prog.stream || "Fusion");
    setNewProgStartDate(prog.start_date || "");
    setNewProgCover(prog.coverImage || "");
    setNewProgType((prog.type as "program" | "session_folder" | "GroupPT") || "program");
    setNewProgWeeks(prog.weeks || 4);
    setNewProgDays(prog.daysPerWeek || 3);
    const loadedNotes = prog.weekNotes || {};
    const normalizedNotes: Record<number, any> = {};
    Object.keys(loadedNotes).forEach(k => {
      const key = Number(k);
      if (typeof loadedNotes[key] === 'string') {
        normalizedNotes[key] = { notes: loadedNotes[key] };
      } else {
        normalizedNotes[key] = loadedNotes[key] || {};
      }
    });
    setProgWeekNotes(normalizedNotes);
    
    const workouts = prog.workouts?.length ? prog.workouts.map((w: any, idx: number) => ({
      id: `w_${Date.now()}_${idx}`,
      name: w.name,
      week: w.week,
      day: w.day,
      minDays: w.minDays,
      dayCounts: w.dayCounts,
      date: w.date,
      exercises: w.exercises.map((e: any, eIdx: number) => ({
        id: Date.now() + eIdx + Math.random(),
        isSection: e.isSection,
        sectionType: e.sectionType || "Normal",
        description: e.description,
        blockType: e.blockType || "Strength",
        name: e.name,
        sets: e.sets,
        reps: e.reps,
        weight: e.weight || 0,
        distance: e.distance || 0,
        timeMins: e.timeMins || 0,
        timeSecs: e.timeSecs || 0,
        rest: e.rest || 0,
        linkedToNext: e.linkedToNext || false,
        eachSide: e.eachSide || false,
        staffNotes: e.staffNotes || "",
        coachingNotes: e.coachingNotes || ""
      }))
    })) : [];
    
    setProgWorkouts(workouts);
    setSelectedWorkoutIndex(0);
    setProgViewMode("day");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteProgram = (id: string) => {
    const updated = programs.filter(p => p.id !== id);
    setPrograms(updated);
    savePrograms(updated).then(r => {
      if (r.success) toast.success("Program deleted!");
      else toast.warning("Deleted locally — cloud sync failed. It will retry automatically.");
    });
  };

  const handleDuplicateProgram = (id: string) => {
    const programToDuplicate = programs.find(p => p.id === id);
    if (!programToDuplicate) return;
    
    const newProg = {
      ...programToDuplicate,
      id: "p_" + Date.now(),
      name: `${programToDuplicate.name} (Copy)`
    };
    
    const updated = [...programs, newProg];
    setPrograms(updated);
    savePrograms(updated).then(r => {
      if (r.success) toast.success("Program duplicated!");
      else toast.warning("Duplicated locally — cloud sync failed. It will retry automatically.");
    });
  };

  const handleSendBroadcast = async () => {
    if (!notifTitle || !notifMessage) {
      toast.error("Please fill in both title and message.");
      return;
    }
    setIsSendingNotif(true);
    try {
      await Promise.all(members.map(m => sendNotification(m.id, notifTitle, notifMessage)));
      toast.success("Broadcast notification sent!");
      setNotifTitle("");
      setNotifMessage("");
    } catch (error) {
      toast.error("Failed to send notification.");
    } finally {
      setIsSendingNotif(false);
    }
  };

  const handleDownloadSource = async () => {
    setIsZipping(true);
    try {
      toast.info("Bundling files... this might take a few seconds.");
      const zip = new JSZip();

      const srcFiles = import.meta.glob('/src/**/*', { query: '?raw' });
      const publicFiles = import.meta.glob('/public/**/*', { query: '?raw' });
      const rootFiles = import.meta.glob('/*.{html,json,js,ts,md,cjs,mjs}', { query: '?raw' });
      
      const allFiles: Record<string, any> = { ...srcFiles, ...publicFiles, ...rootFiles };
      let fileCount = 0;

      for (const path in allFiles) {
        try {
          const module = await (allFiles[path] as () => Promise<{ default: string }>)();
          const content = module.default;
          const cleanPath = path.startsWith('/') ? path.slice(1) : path;
          zip.file(cleanPath, content);
          fileCount++;
        } catch (e) {
          console.warn(`Could not read ${path}`, e);
        }
      }

      if (fileCount === 0) {
        throw new Error("No files found to bundle.");
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'fittrack-source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(`Source code downloaded! (${fileCount} files)`);
    } catch (error) {
      console.error(error);
      toast.error("Failed to download source code.");
    } finally {
      setIsZipping(false);
    }
  };

  const autoSaveProgram = async (workoutsToSave: any[]) => {
    const progId = editingProgramId || "p_" + Date.now();
    if (!editingProgramId) {
      setEditingProgramId(progId);
    }
    const week1Start = progWeekNotes[1]?.start_date || newProgStartDate || null;
    const newProg = {
      id: progId,
      name: newProgName || "Untitled AI Program",
      description: newProgDesc,
      stream: newProgStream,
      start_date: week1Start,
      coverImage: newProgCover,
      type: newProgType,
      weeks: newProgType === "GroupPT" ? 12 : newProgWeeks,
      daysPerWeek: newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays,
      weekNotes: progWeekNotes,
      workouts: workoutsToSave.map(w => {
        const exercises = w.exercises.map((e: any) => ({ isSection: e.isSection, sectionType: e.sectionType || "Normal", description: e.description, blockType: e.blockType || "Strength", name: e.name, sets: e.sets, reps: e.reps, weight: e.weight, distance: e.distance, timeMins: e.timeMins, timeSecs: e.timeSecs, rest: e.rest || 0, linkedToNext: e.linkedToNext, eachSide: e.eachSide, staffNotes: e.staffNotes, coachingNotes: e.coachingNotes }));
        applyWarmupFireupSupersets(exercises);
        return {
          name: w.name,
          week: w.week,
          day: w.day,
          minDays: w.minDays,
          dayCounts: w.dayCounts,
          date: w.date,
          exercises
        };
      })
    };
    
    let updated;
    if (editingProgramId) {
      updated = programs.map(p => p.id === progId ? newProg : p);
    } else {
      updated = [...programs, newProg];
    }
    setPrograms(updated);
    const result = await savePrograms(updated);
    if (!result.success) toast.warning("AI programme saved locally — cloud sync failed. It will retry automatically.");
    return result;
  };

  const [genProgress, setGenProgress] = useState<string | null>(null);

  const mergeCells = (grid: any[], cells: any[]) => {
    const next = [...grid];
    for (const c of cells) {
      const i = next.findIndex((x) => x.week === c.week && x.day === c.day);
      if (i !== -1) {
        next[i] = {
          ...next[i],
          exercises: c.exercises,
          ...(c.name && { name: c.name }),
          ...(c.dayCounts && { dayCounts: c.dayCounts }),
          ...(c.minDays && { minDays: c.minDays })
        };
      } else {
        next.push({ ...c, id: `w_${Date.now()}_${Math.random()}`, name: c.name || `Week ${c.week}, Day ${c.day}` });
      }
    }
    return next;
  };

  const streamCfg = () => ({ weeks: newProgWeeks, days: newProgType === "program" ? 5 : newProgDays, stream: newProgStream });
  const exPayload = () => {
    const pool = (newProgStream === "Foundations")
      ? exercises.filter(ex => String(ex.difficulty || "").toLowerCase() === "beginner")
      : exercises;
    return pool.map(ex => ({
      id: ex.id, name: ex.name, category: ex.category,
      movementType: ex.movementType, equipment: ex.equipment,
      difficulty: ex.difficulty
    }));
  };

  const handleGenerateQuick = async () => {
    setIsGeneratingAI(true);
    let grid = [...progWorkouts];
    let previousWeekWorkouts: any[] = [];
    const previousProgramWorkouts = programs.find((p: any) => p.type !== "GroupPT" && p.id !== editingProgramId)?.workouts || [];
    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
    const generateWeekWithRetry = async (w: number, tries = 3): Promise<any[]> => {
      let lastErr;
      for (let i = 0; i < tries; i++) {
        try {
          const { data, error } = await supabase.functions.invoke("generate-workout", {
            body: { action: "week", program: streamCfg(), currentWorkouts: [], week: w, exercises: exPayload(), previousWeekWorkouts, previousProgramWorkouts },
          });
          if (error) throw new Error(error.message);
          if (data?.error) throw new Error(data.error);
          return data.workouts || [];
        } catch (e) { lastErr = e; await sleep(2000 * (i + 1)); }
      }
      throw lastErr;
    };
    try {
      const failed: number[] = [];
      for (let w = 1; w <= newProgWeeks; w++) {
        setGenProgress(`Quick draft — week ${w}/${newProgWeeks}…`);
        let cells: any[] = [];
        try { cells = await generateWeekWithRetry(w); }
        catch { failed.push(w); continue; }
        cells.forEach((c: any) => {
          if (c.exercises) {
            c.exercises = fixWarmup(c.exercises, c.day - 1, exercises);
            applyWarmupFireupSupersets(c.exercises);
          }
        });
        grid = mergeCells(grid, cells);
        previousWeekWorkouts = cells;
        setProgWorkouts([...grid]);
      }
      await autoSaveProgram(grid);
      if (failed.length) toast.warning(`Generated, but weeks ${failed.join(", ")} failed — re-run to fill them.`);
      else toast.success("Quick draft generated!");
    } catch (e: any) {
      toast.error(`Generation failed: ${e.message}`);
    } finally {
      setIsGeneratingAI(false);
      setGenProgress(null);
    }
  };

  const handleGenerateFullAI = async () => {
    setIsGeneratingAI(true);
    let grid = [...progWorkouts];
    const byWeek = (w: number) => grid.filter((c) => c.week === w);
    
    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
    
    const generateCellWithRetry = async (bodyPayload: any, tries = 3) => {
      let lastErr;
      for (let i = 0; i < tries; i++) {
        try {
          const { data, error } = await supabase.functions.invoke("generate-workout", { body: bodyPayload });
          if (error) throw new Error(error.message);
          if (data?.error) throw new Error(data.error);
          const cell = (data.workouts || [])[0];
          if (cell?.exercises) {
            cell.exercises = fixWarmup(cell.exercises, cell.day - 1, exercises);
            applyWarmupFireupSupersets(cell.exercises);
          }
          return cell;
        } catch (e) {
          lastErr = e;
          await sleep(2000 * (i + 1));
        }
      }
      throw lastErr;
    };

    try {
      let generatedCount = 0;
      const previousProgramWorkouts = programs.find((p: any) => p.type !== "GroupPT" && p.id !== editingProgramId)?.workouts || [];
      for (let w = 1; w <= newProgWeeks; w++) {
        const previousWeekWorkouts = w > 1 ? byWeek(w - 1) : [];
        const daysToGen = newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays;
        for (let d = 1; d <= daysToGen; d++) {
          const existingCell = grid.find((c) => c.week === w && c.day === d);
          if (existingCell && existingCell.exercises && existingCell.exercises.length > 0) {
            continue;
          }
          
          setGenProgress(`Full AI plan — week ${w}, day ${d}…`);
          const cell = await generateCellWithRetry({
            action: "single", program: streamCfg(), currentWorkouts: [],
            week: w, day: d, exercises: exPayload(), previousWeekWorkouts, weekSoFar: byWeek(w), previousProgramWorkouts
          });
          
          if (cell) {
            grid = mergeCells(grid, [cell]);
            setProgWorkouts([...grid]);
            await autoSaveProgram(grid);
            generatedCount++;
          }
          await sleep(600);
        }
      }
      if (generatedCount > 0) {
        toast.success("Full AI plan generated!");
      } else {
        toast.info("Program is already fully generated.");
      }
    } catch (e: any) {
      toast.error(`Generation failed: ${e.message}`);
    } finally {
      setIsGeneratingAI(false);
      setGenProgress(null);
    }
  };

  const handleEdgeFunctionAI = async (workoutIndex: number | null, action: "generate" | "regenerate" | "edit") => {
    setIsGeneratingAI(true);
    const previousProgramWorkouts = programs.find((p: any) => p.type !== "GroupPT" && p.id !== editingProgramId)?.workouts || [];
    try {
      const t = progWorkouts[workoutIndex ?? -1];
      const wk = t?.week, dy = t?.day;
      const previousWeekWorkouts = (wk && wk > 1) ? progWorkouts.filter((c: any) => c.week === wk - 1) : [];
      const weekSoFar = wk ? progWorkouts.filter((c: any) => c.week === wk && c.day !== dy) : [];

      const { data, error } = await supabase.functions.invoke('generate-workout', {
        body: {
          action: "single",
          program: streamCfg(),
          targetWorkoutIndex: workoutIndex,
          currentWorkouts: progWorkouts,
          exercises: exPayload(),
          previousWeekWorkouts,
          weekSoFar,
          previousProgramWorkouts
        }
      });

      if (error) throw new Error(error.message || "Failed to generate workout");
      if (!data || !data.workouts) throw new Error("No workouts returned from AI");

      const workouts = data.workouts;
      workouts.forEach((c: any) => {
        if (c.exercises) {
          c.exercises = fixWarmup(c.exercises, c.day - 1, exercises);
          applyWarmupFireupSupersets(c.exercises);
        }
      });

      setProgWorkouts(workouts);
      await autoSaveProgram(workouts);
      toast.success(`AI successfully completed: ${action}!`);
    } catch (err: any) {
      console.error(err);
      toast.error(`AI Generation failed: ${err.message}`);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const GROUP_PT_WEEKS = 12;
  const [genCycle, setGenCycle] = useState(0);

  async function callGroupGen(body: any) {
    const { data, error } = await supabase.functions.invoke("generate-group-pt", { body });
    if (error) throw new Error(error.message);
    if (data?.error) throw new Error(data.error);
    const cells = data.workouts || [];
    cells.forEach((c: any) => {
      if (c.exercises) {
        c.exercises = fixWarmup(c.exercises, c.day - 1, exercises);
        applyWarmupFireupSupersets(c.exercises);
      }
    });
    return cells;
  }

  async function generateGroupBlock() {
    setIsGeneratingAI(true);
    let current = progWorkouts;
    const previousGroupPTProgram = programs.find((p: any) => p.type === "GroupPT" && p.id !== editingProgramId);
    const previousBlock = previousGroupPTProgram?.workouts || [];
    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
    const callGroupGenRetry = async (body: any, tries = 3): Promise<any[]> => {
      let lastErr;
      for (let i = 0; i < tries; i++) {
        try { return await callGroupGen(body); }
        catch (e) { lastErr = e; await sleep(2500 * (i + 1)); }
      }
      throw lastErr;
    };

    const failed: number[] = [];
    try {
      for (let cw = 1; cw <= 4; cw++) {
        setGenCycle(cw);
        try {
          current = await callGroupGenRetry({
            action: "week",
            program: { weeks: GROUP_PT_WEEKS, days: newProgDays },
            currentWorkouts: current,
            exercises: exPayload(),
            cycleWeek: cw,
            previousBlockWorkouts: previousBlock,
          });
          setProgWorkouts([...current]);
          await autoSaveProgram(current);   // save after each template week so nothing is lost
        } catch (e: any) {
          failed.push(cw);  // record and carry on to the other template weeks
        }
      }
      if (failed.length) {
        toast.warning(`Generated, but template week(s) ${failed.join(", ")} failed — press Generate again to fill the gaps.`);
      } else {
        toast.success("Group PT block generated successfully!");
      }
    } finally {
      setIsGeneratingAI(false);
      setGenCycle(0);
    }
  }

  async function regenerateGroupCell(index: number) {
    setIsGeneratingAI(true);
    const previousGroupPTProgram = programs.find((p: any) => p.type === "GroupPT" && p.id !== editingProgramId);
    const previousBlock = previousGroupPTProgram?.workouts || [];

    try {
      const updated = await callGroupGen({
        action: "single",
        program: { weeks: GROUP_PT_WEEKS, days: newProgDays },
        currentWorkouts: progWorkouts,
        exercises: exPayload(),
        targetWorkoutIndex: index,
        previousBlockWorkouts: previousBlock,
      });
      setProgWorkouts(updated);
      await autoSaveProgram(updated);
      toast.success("Group PT session regenerated successfully!");
    } catch (e: any) {
      toast.error("Regenerate failed: " + e.message);
    } finally {
      setIsGeneratingAI(false);
    }
  }



  const handleDeleteWow = async (id: string) => {
    if (!confirm("Are you sure you want to delete this Workout of the Week?")) return;
    const { error } = await supabase.from('workout_of_week').delete().eq('id', id);
    if (!error) {
      toast.success("WOW deleted");
      setWows(await getWorkoutsOfWeek());
    } else {
      toast.error(`Failed to delete WOW: ${error.message}`);
    }
  };

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 max-w-5xl mx-auto w-full">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-4xl font-heading tracking-wider">Staff Hub</h2>
      </div>

      <Tabs value={activeTab} onValueChange={(v) => { setActiveTab(v); ensureTabData(v); }} className="w-full">
        <TabsList className="flex w-full max-w-[1300px] overflow-x-auto justify-start h-auto p-1">
          <TabsTrigger value="exercises">Manage Exercises</TabsTrigger>
          <TabsTrigger value="programs">Manage Programs</TabsTrigger>
          <TabsTrigger value="wow">Workout of the Week</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
          <TabsTrigger value="display">TV Display</TabsTrigger>
          <TabsTrigger value="members">Members</TabsTrigger>
          <TabsTrigger value="nutrition">Nutrition</TabsTrigger>

          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="exercises" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Add New Exercise</CardTitle>
              <CardDescription>Add a new exercise to the global library.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input value={newExName} onChange={e => setNewExName(e.target.value)} placeholder="e.g. Incline Press" />
                </div>
                <div className="space-y-2">
                  <Label>Categories (Block Types)</Label>
                  <div className="flex flex-wrap gap-4 pt-2">
                    {["Strength", "Cardio", "Mobility", "Activation"].map(cat => (
                      <div key={cat} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`new-cat-${cat}`} 
                          checked={newExCategory.includes(cat)}
                          onCheckedChange={(checked) => {
                            if (checked) setNewExCategory([...newExCategory, cat]);
                            else setNewExCategory(newExCategory.filter(c => c !== cat));
                          }}
                        />
                        <label htmlFor={`new-cat-${cat}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{cat}</label>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Muscle Group</Label>
                  <Input value={newExMuscle} onChange={e => setNewExMuscle(e.target.value)} placeholder="e.g. Chest" />
                </div>
                <div className="space-y-2">
                  <Label>Movement Type</Label>
                  <div className="flex flex-wrap gap-4 pt-2">
                    {MOVEMENT_TYPES.map(m => (
                      <div key={m} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`new-mov-${m}`} 
                          checked={newExMovement.includes(m)}
                          onCheckedChange={(checked) => {
                            if (checked) setNewExMovement([...newExMovement, m]);
                            else setNewExMovement(newExMovement.filter(v => v !== m));
                          }}
                        />
                        <label htmlFor={`new-mov-${m}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{m}</label>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Equipment</Label>
                  <Select value={newExEq} onValueChange={setNewExEq}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Barbell">Barbell</SelectItem>
                      <SelectItem value="Dumbbell">Dumbbell</SelectItem>
                      <SelectItem value="Kettlebell">Kettlebell</SelectItem>
                      <SelectItem value="Machine">Machine</SelectItem>
                      <SelectItem value="Bodyweight">Bodyweight</SelectItem>
                      <SelectItem value="Cable">Cable</SelectItem>
                      <SelectItem value="Bands">Bands</SelectItem>
                      <SelectItem value="Wall Balls">Wall Balls</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Difficulty</Label>
                  <Select value={newExDiff} onValueChange={setNewExDiff}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Tracking Style</Label>
                  <div className="flex flex-wrap gap-4 pt-2">
                    {TRACKING_TYPES.map(t => (
                      <div key={t} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`new-track-${t}`} 
                          checked={newExTracking.includes(t)}
                          onCheckedChange={(checked) => {
                            if (checked) setNewExTracking([...newExTracking, t]);
                            else setNewExTracking(newExTracking.filter(v => v !== t));
                          }}
                        />
                        <label htmlFor={`new-track-${t}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{t}</label>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Video URL (Vimeo embedded link)</Label>
                  <Input value={newExVid} onChange={e => setNewExVid(e.target.value)} placeholder="e.g. https://player.vimeo.com/video/147173661" />
                </div>
              </div>
              <Button onClick={handleAddExercise} className="gap-2">
                <Plus className="h-4 w-4" /> Add Exercise
              </Button>
            </CardContent>
          </Card>

          <div className="flex flex-col gap-4 mt-6 mb-4">
            <div className="flex flex-col sm:flex-row gap-4 items-center flex-wrap">
              <Input 
                placeholder="Search exercises to edit or delete..." 
                value={librarySearch}
                onChange={e => setLibrarySearch(e.target.value)}
                className="max-w-md w-full sm:w-auto"
              />
              
              <Select value={catF} onValueChange={setCatF}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {catOpts.map(o => (
                    <SelectItem key={o} value={o}>{o === "All" ? "All Categories" : o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={muscleF} onValueChange={setMuscleF}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Muscle Group" />
                </SelectTrigger>
                <SelectContent>
                  {muscleOpts.map(o => (
                    <SelectItem key={o} value={o}>{o === "All" ? "All Muscles" : o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={moveF} onValueChange={setMoveF}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Movement Type" />
                </SelectTrigger>
                <SelectContent>
                  {moveOpts.map(o => (
                    <SelectItem key={o} value={o}>{o === "All" ? "All Movements" : o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={equipF} onValueChange={setEquipF}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Equipment" />
                </SelectTrigger>
                <SelectContent>
                  {equipOpts.map(o => (
                    <SelectItem key={o} value={o}>{o === "All" ? "All Equipment" : o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={diffF} onValueChange={setDiffF}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Difficulty" />
                </SelectTrigger>
                <SelectContent>
                  {diffOpts.map(o => (
                    <SelectItem key={o} value={o}>{o === "All" ? "All Difficulties" : o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={trackF} onValueChange={setTrackF}>
                <SelectTrigger className="w-full sm:w-[150px]">
                  <SelectValue placeholder="Tracking Style" />
                </SelectTrigger>
                <SelectContent>
                  {trackOpts.map(o => (
                    <SelectItem key={o} value={o}>{o === "All" ? "All Tracking Styles" : o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-4 flex-wrap">
              <Button 
                variant="outline" 
                onClick={() => {
                  setLibrarySearch("");
                  setCatF("All");
                  setMuscleF("All");
                  setMoveF("All");
                  setEquipF("All");
                  setDiffF("All");
                  setTrackF("All");
                }}
              >
                Clear filters
              </Button>
              <span className="text-sm text-muted-foreground">
                Showing {filteredLibrary.length} of {exercises.length} exercises
              </span>
              
              {(librarySearch || catF !== "All" || muscleF !== "All" || moveF !== "All" || equipF !== "All" || diffF !== "All" || trackF !== "All") && (
                <Button variant="destructive" onClick={handleBulkDelete}>
                  Delete All Showing ({filteredLibrary.length})
                </Button>
              )}
              
              <div className="flex gap-2 ml-auto">
              <Button variant="outline" className="gap-2" onClick={() => {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.csv';
                input.onchange = (e: any) => {
                  const file = e.target.files[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = (event) => {
                    try {
                      const text = event.target?.result as string;
                      const rows = text.split('\n').filter(row => row.trim());
                      if (rows.length <= 1) return;
                      
                      const newExercises = rows.slice(1).map(row => {
                        const cols = [];
                        let curr = '';
                        let inQuotes = false;
                        for (let i = 0; i < row.length; i++) {
                          if (row[i] === '"') inQuotes = !inQuotes;
                          else if (row[i] === ',' && !inQuotes) {
                            cols.push(curr.trim().replace(/^"|"$/g, ''));
                            curr = '';
                          } else {
                            curr += row[i];
                          }
                        }
                        cols.push(curr.trim().replace(/^"|"$/g, ''));
                        
                        const name = cols[1] || "";
                        return {
                          id: cols[0] || name.toLowerCase().replace(/\s+/g, '-') || `ex_${Date.now()}_${Math.random()}`,
                          name: name,
                          category: cols[2] ? cols[2].split(';').map(s => s.trim()).filter(Boolean) : ["Strength"],
                          muscle: cols[3],
                          equipment: cols[4],
                          difficulty: cols[5],
                          movementType: cols[6] ? cols[6].split(';').map(s => s.trim()).filter(Boolean) : ["Push"],
                          videoUrl: cols[7] || "",
                          trackingType: cols[8] ? cols[8].split(';').map(s => s.trim()).filter(Boolean) : ["Weight & Reps"]
                        };
                      });
                      
                      let validExercises = newExercises.filter(ex => ex.name);
                      const uniqueMap = new Map();
                      validExercises.forEach(ex => uniqueMap.set(ex.id, ex));
                      validExercises = Array.from(uniqueMap.values());

                      setExercises(validExercises);
                      toast.info("Saving and syncing to cloud...");
                      saveExercises(validExercises).then((res: any) => {
                        if (res && res.error) {
                          toast.error("Cloud sync failed: " + res.error.message, { duration: 10000 });
                        } else {
                          toast.success(`Imported ${validExercises.length} exercises!`);
                        }
                      });
                    } catch (err) {
                      toast.error("Failed to parse CSV.");
                    }
                  };
                  reader.readAsText(file);
                };
                input.click();
              }}>
                <Download className="h-4 w-4 rotate-180" /> Import CSV
              </Button>
              <Button variant="outline" className="gap-2" onClick={handleExportData}>
                <Download className="h-4 w-4" /> Backup to CSV
              </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredLibrary.slice(0, exCardLimit).map((ex) => (
              <Card key={ex.id} className="bg-muted/50 border-border flex flex-col">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center justify-between">
                    {ex.name}
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => setEditingExercise(ex)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => handleDeleteExercise(ex.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardTitle>
                  <CardDescription>{Array.isArray(ex.category) ? ex.category.join(", ") : ex.category} • {ex.muscle} • {ex.equipment}{ex.movementType ? ` • ${Array.isArray(ex.movementType) ? ex.movementType.join(", ") : ex.movementType}` : ""}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
          {filteredLibrary.length > exCardLimit && (
            <div className="flex justify-center pt-4">
              <Button variant="outline" onClick={() => setExCardLimit(l => l + 60)}>
                Load more ({filteredLibrary.length - exCardLimit} remaining)
              </Button>
            </div>
          )}

          <Dialog open={!!editingExercise} onOpenChange={(open) => !open && setEditingExercise(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Exercise</DialogTitle>
              </DialogHeader>
              {editingExercise && (
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input value={editingExercise.name} onChange={e => setEditingExercise({...editingExercise, name: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Categories (Block Types)</Label>
                    <div className="flex flex-wrap gap-4 pt-2">
                      {["Strength", "Cardio", "Mobility", "Activation"].map(cat => {
                        const currentCats = Array.isArray(editingExercise.category) ? editingExercise.category : [editingExercise.category || "Strength"];
                        return (
                          <div key={cat} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`edit-cat-${cat}`} 
                              checked={currentCats.includes(cat)}
                              onCheckedChange={(checked) => {
                                let newCats = [...currentCats];
                                if (checked && !newCats.includes(cat)) newCats.push(cat);
                                else if (!checked) newCats = newCats.filter(c => c !== cat);
                                setEditingExercise({...editingExercise, category: newCats});
                              }}
                            />
                            <label htmlFor={`edit-cat-${cat}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{cat}</label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Muscle Group</Label>
                    <Input value={editingExercise.muscle} onChange={e => setEditingExercise({...editingExercise, muscle: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Movement Type</Label>
                    <div className="flex flex-wrap gap-4 pt-2">
                      {MOVEMENT_TYPES.map(m => {
                        const currentMovs = Array.isArray(editingExercise.movementType) ? editingExercise.movementType : (editingExercise.movementType ? [editingExercise.movementType] : ["Push"]);
                        return (
                          <div key={m} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`edit-mov-${m}`} 
                              checked={currentMovs.includes(m)}
                              onCheckedChange={(checked) => {
                                let newMovs = [...currentMovs];
                                if (checked && !newMovs.includes(m)) newMovs.push(m);
                                else if (!checked) newMovs = newMovs.filter(v => v !== m);
                                setEditingExercise({...editingExercise, movementType: newMovs});
                              }}
                            />
                            <label htmlFor={`edit-mov-${m}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{m}</label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Equipment</Label>
                    <Select value={editingExercise.equipment} onValueChange={v => setEditingExercise({...editingExercise, equipment: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Barbell">Barbell</SelectItem>
                        <SelectItem value="Dumbbell">Dumbbell</SelectItem>
                        <SelectItem value="Kettlebell">Kettlebell</SelectItem>
                        <SelectItem value="Machine">Machine</SelectItem>
                        <SelectItem value="Bodyweight">Bodyweight</SelectItem>
                        <SelectItem value="Cable">Cable</SelectItem>
                        <SelectItem value="Bands">Bands</SelectItem>
                        <SelectItem value="Wall Balls">Wall Balls</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Difficulty</Label>
                    <Select value={editingExercise.difficulty} onValueChange={v => setEditingExercise({...editingExercise, difficulty: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Beginner">Beginner</SelectItem>
                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                        <SelectItem value="Advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Tracking Style</Label>
                    <div className="flex flex-wrap gap-4 pt-2">
                      {TRACKING_TYPES.map(t => {
                        const rawTrack = editingExercise.trackingType ?? "Weight & Reps";
                        const currentTracking = (Array.isArray(rawTrack) ? rawTrack : String(rawTrack).split(/[;,]/)).map(s => s.trim()).filter(Boolean);
                        return (
                          <div key={t} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`edit-track-${t}`} 
                              checked={currentTracking.includes(t)}
                              onCheckedChange={(checked) => {
                                let newTracking = [...currentTracking];
                                if (checked && !newTracking.includes(t)) newTracking.push(t);
                                else if (!checked) newTracking = newTracking.filter(v => v !== t);
                                setEditingExercise({...editingExercise, trackingType: newTracking});
                              }}
                            />
                            <label htmlFor={`edit-track-${t}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{t}</label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Video URL</Label>
                    <Input value={editingExercise.videoUrl || ""} onChange={e => setEditingExercise({...editingExercise, videoUrl: e.target.value})} />
                  </div>
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditingExercise(null)}>Cancel</Button>
                <Button onClick={handleUpdateExercise}>Save Changes</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="programs" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>{newProgType === "wow" ? (editingProgramId ? "Edit Workout of the Week" : "Create Workout of the Week") : (editingProgramId ? "Edit Ready-Made Program" : "Create Ready-Made Program")}</CardTitle>
              <CardDescription>{newProgType === "wow" ? "Build a weekly benchmark workout for members." : "Build a workout template for members to use."}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{newProgType === "wow" ? "WOW Name" : "Program Name"}</Label>
                    <Input value={newProgName} onChange={e => setNewProgName(e.target.value)} placeholder={newProgType === "wow" ? "e.g. Benchmark Test" : "e.g. 12-Week Strength"} />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input value={newProgDesc} onChange={e => setNewProgDesc(e.target.value)} placeholder="Short description" />
                  </div>
                  {newProgType !== "wow" && (
                    <div className="space-y-2 md:col-span-2">
                      <Label>Cover Image (Optional)</Label>
                      <div className="flex gap-2">
                        <Input value={newProgCover} onChange={e => setNewProgCover(e.target.value)} placeholder="e.g. https://example.com/image.jpg" className="flex-1" />
                        <div className="relative">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                            disabled={isUploadingImage}
                            title="Upload image"
                          />
                          <Button type="button" variant="outline" disabled={isUploadingImage} className="gap-2 w-[110px]">
                            {isUploadingImage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                            {isUploadingImage ? "Uploading" : "Upload"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                  <div className="space-y-2 md:col-span-2">
                    <Label>Program Structure</Label>
                    <Select value={newProgType} onValueChange={(v: "program" | "session_folder" | "GroupPT" | "wow") => {
                      setNewProgType(v);
                      if (v === "wow") {
                        setProgWorkouts([{ week: 1, day: 1, date: "", name: "Workout of the Week", exercises: [] }]);
                      }
                    }}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="program">Structured Program (Weeks/Days)</SelectItem>
                        <SelectItem value="session_folder">Session Folder (Standalone Sessions)</SelectItem>
                        <SelectItem value="GroupPT">Group PT (12-Week Block)</SelectItem>
                        <SelectItem value="wow">Workout of the Week (WOW)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {newProgType === "wow" && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:col-span-2">
                      <div className="space-y-2">
                        <Label>Score Type</Label>
                        <Select value={wowScoreType} onValueChange={setWowScoreType}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="time">For Time</SelectItem>
                            <SelectItem value="reps">Total Reps</SelectItem>
                            <SelectItem value="distance">Distance</SelectItem>
                            <SelectItem value="calories">Calories</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Week Start Date (Monday)</Label>
                        <Input type="date" value={wowWeekStart} onChange={e => setWowWeekStart(e.target.value)} />
                      </div>
                      <div className="flex items-center space-x-2 pt-8">
                        <Checkbox id="wowScaled" checked={wowScaledAllowed} onCheckedChange={(c) => setWowScaledAllowed(!!c)} />
                        <Label htmlFor="wowScaled">Allow Scaled Option</Label>
                      </div>
                    </div>
                  )}
                  {(newProgType === "program" || newProgType === "GroupPT") && (
                    <>
                      {newProgType === "program" && (
                        <div className="space-y-2">
                          <Label>Stream</Label>
                          <Select value={newProgStream} onValueChange={setNewProgStream}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Foundations">Foundations</SelectItem>
                              <SelectItem value="Stronger">Stronger</SelectItem>
                              <SelectItem value="Fusion">Fusion</SelectItem>
                              <SelectItem value="Performance">Performance</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}

                      <div className="space-y-2">
                        <Label>Length (Weeks)</Label>
                        <Input 
                          type="number" 
                          min="1" 
                          max="52" 
                          value={newProgType === "GroupPT" ? 12 : newProgWeeks} 
                          onChange={e => setNewProgWeeks(parseInt(e.target.value) || 1)} 
                          disabled={newProgType === "GroupPT"}
                        />
                      </div>
                      {newProgType !== "program" && (
                        <div className="space-y-2">
                          <Label>Days per Week</Label>
                          <Input type="number" min="1" max="7" value={newProgDays} onChange={e => setNewProgDays(parseInt(e.target.value) || 1)} />
                        </div>
                      )}
                    </>
                  )}
                </div>
                
                {progWorkouts.length === 0 ? (
                  <div className="flex flex-col gap-2">
                    <Button onClick={handleGenerateWorkoutSlots} className="w-full">Generate Workout Grid</Button>
                    {newProgType === "GroupPT" ? (
                      <Button 
                        variant="outline" 
                        onClick={generateGroupBlock} 
                        className="w-full gap-2 border-primary text-primary hover:bg-primary/10"
                        disabled={isGeneratingAI}
                      >
                        {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                        {genCycle > 0 ? `Generating template week ${genCycle}/4…` : "Generate 12-week Group PT block"}
                      </Button>
                    ) : (
                      <>
                        <Button 
                          variant="outline" 
                          onClick={handleGenerateQuick} 
                          className="w-full gap-2 border-primary text-primary hover:bg-primary/10"
                          disabled={isGeneratingAI || !newProgStream}
                        >
                          {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                          {genProgress || "Quick generate"}
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={handleGenerateFullAI} 
                          className="w-full gap-2 border-primary text-primary hover:bg-primary/10"
                          disabled={isGeneratingAI || !newProgStream}
                        >
                          {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                          {genProgress || "Full AI plan (slower)"}
                        </Button>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="space-y-6 pt-4 border-t border-border">
                    {(newProgType === "program" || newProgType === "GroupPT") && (
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          {newProgType === "program" && progWorkouts.some(w => !w.exercises || w.exercises.length === 0) && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={handleGenerateFullAI} 
                              className="gap-2 border-primary text-primary hover:bg-primary/10"
                              disabled={isGeneratingAI || !newProgStream}
                            >
                              {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                              {genProgress || "Resume AI generation"}
                            </Button>
                          )}
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setProgViewMode(m => m === "day" ? "full" : "day")} className="gap-2">
                          <CalendarIcon className="h-4 w-4" />
                          {progViewMode === "day" ? "Full Program View" : "Day View"}
                        </Button>
                      </div>
                    )}
                    
                    {progWorkouts.length > 0 && (newProgType === "program" || newProgType === "GroupPT") && (
                      <div className="bg-muted/40 p-3 rounded-md border border-border text-sm flex flex-col gap-2">
                        <div className="flex items-center gap-2 font-bold text-foreground/80">
                          <Sparkles className="h-4 w-4 text-primary" />
                          How members see this week
                        </div>
                        <p className="text-muted-foreground text-xs leading-relaxed">
                          {newProgStream === "Stronger" ? (
                            <>2 days → Full Body A + B &middot; 3 days → Push/Pull/Legs &middot; 4 days → + Mobility & Cardio &middot; 5 days → + Full Body. Each session's badge shows which plans include it.</>
                          ) : newProgStream === "Foundations" ? (
                            <>2 days → Full Body A + B &middot; 3 days → + Full Body C &middot; 4 days → + Strength + Easy Cardio &middot; 5 days → + Move & Recover. Each session's badge shows which plans include it.</>
                          ) : (
                            <>Sessions are filtered by the member's preferred training frequency (2-5 days). The badge on each session shows which plans include it.</>
                          )}
                        </p>
                      </div>
                    )}

                    {progViewMode === "full" && (newProgType === "program" || newProgType === "GroupPT") ? (
                      <div className="space-y-8">
                        {Array.from({ length: newProgType === "GroupPT" ? 12 : newProgWeeks }).map((_, wIdx) => {
                          const weekNum = wIdx + 1;
                          return (
                            <div key={weekNum} className="space-y-4">
                              <h4 className="font-bold text-lg border-b pb-2">Week {weekNum}</h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                                {Array.from({ length: newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays }).map((_, dIdx) => {
                                  const dayNum = dIdx + 1;
                                  const workout = progWorkouts.find(w => w.week === weekNum && w.day === dayNum);
                                  return (
                                    <Card key={dayNum} className="bg-muted/30 border-border flex flex-col cursor-pointer hover:border-primary transition-colors h-full min-h-[120px]" onClick={() => {
                                      setSelectedWeek(weekNum);
                                      setSelectedDay(dayNum);
                                      setProgViewMode("day");
                                      const idx = progWorkouts.findIndex(w => w.week === weekNum && w.day === dayNum);
                                      if(idx >= 0) setSelectedWorkoutIndex(idx);
                                      window.scrollTo({ top: 0, behavior: 'smooth' });
                                    }}>
                                      <CardHeader className="p-3 pb-2">
                                        <div className="flex justify-between items-start gap-2">
                                          <CardTitle className="text-sm">Day {dayNum}</CardTitle>
                                          {(() => {
                                            const dayCounts = workout?.dayCounts;
                                            const minDays = workout?.minDays;
                                            if (!dayCounts && !minDays) return null;
                                            
                                            let label = "";
                                            let isTwoDay = false;
                                            if (dayCounts) {
                                              const counts = [...dayCounts].sort((a,b) => a-b);
                                              if (counts.length === 1 && counts[0] === 2) { label = "2-DAY PLAN"; isTwoDay = true; }
                                              else if (counts.length === 1) label = `${counts[0]}-DAY ONLY`;
                                              else if (counts.length === 4 && counts[0] === 2 && counts[3] === 5) label = "ALL PLANS";
                                              else if (counts.length > 1 && counts[counts.length-1] - counts[0] === counts.length - 1) label = `${counts[0]}-${counts[counts.length-1]} DAY`;
                                              else label = counts.join(",") + " DAY";
                                            } else if (minDays) {
                                              if (minDays === 2) label = "ALL PLANS";
                                              else if (minDays === 5) label = "5-DAY ONLY";
                                              else label = `${minDays}-5 DAY`;
                                            }

                                            return (
                                              <Badge variant={isTwoDay ? "default" : "outline"} className={cn("text-[8px] px-1 py-0 h-4 uppercase whitespace-nowrap", isTwoDay ? "bg-primary/20 text-primary border-primary/30" : "text-muted-foreground")}>
                                                {label}
                                              </Badge>
                                            );
                                          })()}
                                        </div>
                                      </CardHeader>
                                      <CardContent className="p-3 pt-0 flex-1 flex flex-col">
                                        {workout?.dayCounts?.length === 1 && workout?.dayCounts[0] === 2 && (
                                          <div className="text-[10px] text-primary font-medium mb-2 leading-tight bg-primary/5 p-1.5 rounded border border-primary/10">
                                            Done instead of Push/Pull/Legs
                                          </div>
                                        )}
                                        {workout?.exercises?.length > 0 ? (
                                          <div className="space-y-1 text-xs">
                                            {workout.exercises.map((ex: any, i: number) => {
                                              const isSupersetItem = ex.linkedToNext || (i > 0 && workout.exercises[i - 1].linkedToNext);
                                              
                                              let detailText = "";
                                              if (ex.sets && ex.reps) detailText = `${ex.sets}x${ex.reps}`;
                                              else if (ex.timeMins || ex.timeSecs) detailText = `${ex.timeMins || 0}m ${ex.timeSecs || 0}s`;
                                              else if (ex.distance) detailText = `${ex.distance}m`;

                                              return (
                                                <div key={i} className={ex.isSection ? "font-bold mt-2 text-primary" : "text-muted-foreground flex justify-between gap-1 items-start"}>
                                                  {ex.isSection ? (
                                                    ex.name
                                                  ) : (
                                                    <>
                                                      <div className="flex items-start gap-1 min-w-0">
                                                        {isSupersetItem && <Link2 className="h-3 w-3 shrink-0 text-primary mt-0.5" />}
                                                        <span className="truncate">{exById[String(ex.name)]?.name || ex.name || "Unknown Exercise"}</span>
                                                      </div>
                                                      {detailText && (
                                                        <span className="text-[10px] opacity-70 shrink-0 font-medium whitespace-nowrap">
                                                          {detailText}
                                                        </span>
                                                      )}
                                                    </>
                                                  )}
                                                </div>
                                              );
                                            })}
                                          </div>
                                        ) : (
                                          <div className="text-xs text-muted-foreground italic">Empty session</div>
                                        )}
                                      </CardContent>
                                    </Card>
                                  )
                                })}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {(newProgType === "program" || newProgType === "GroupPT") ? (
                          <div className="space-y-4">
                            <div className="flex gap-2 overflow-x-auto pb-2 border-b border-border">
                              {Array.from({ length: newProgType === "GroupPT" ? 12 : newProgWeeks }).map((_, i) => (
                                <Button 
                                  key={`week-${i+1}`} 
                                  variant={selectedWeek === i + 1 ? "default" : "outline"}
                                  onClick={() => {
                                    setSelectedWeek(i + 1);
                                    setSelectedDay(1);
                                    const idx = progWorkouts.findIndex(w => w.week === i + 1 && w.day === 1);
                                    if(idx >= 0) setSelectedWorkoutIndex(idx);
                                  }}
                                  className="whitespace-nowrap"
                                >
                                  {weekLabel(i + 1)}
                                </Button>
                              ))}
                            </div>
                            <div className="flex gap-2 overflow-x-auto pb-2">
                              {Array.from({ length: newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays }).map((_, i) => (
                                <Button 
                                  key={`day-${i+1}`} 
                                  variant={selectedDay === i + 1 ? "default" : "secondary"}
                                  onClick={() => {
                                    setSelectedDay(i + 1);
                                    const idx = progWorkouts.findIndex(w => w.week === selectedWeek && w.day === i + 1);
                                    if(idx >= 0) setSelectedWorkoutIndex(idx);
                                  }}
                                  className="whitespace-nowrap"
                                >
                                  Day {i + 1}
                                </Button>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="flex gap-2 overflow-x-auto pb-2">
                            {progWorkouts.map((w, idx) => (
                              <Button 
                                key={w.id} 
                                variant={selectedWorkoutIndex === idx ? "default" : "outline"}
                                onClick={() => setSelectedWorkoutIndex(idx)}
                                className="whitespace-nowrap"
                              >
                                {w.name}
                              </Button>
                            ))}
                            {newProgType !== "wow" && (
                              <Button variant="outline" onClick={handleAddSession} className="whitespace-nowrap gap-2">
                                <Plus className="h-4 w-4" /> Add Session
                              </Button>
                            )}
                          </div>
                        )}

                        <div className="bg-muted/30 p-4 rounded-lg border border-border space-y-4">
                          {(newProgType === "program" || newProgType === "GroupPT") && (
                            <div className="space-y-4 mb-6 pb-4 border-b border-border">
                              <div className="flex items-center justify-between">
                                <h3 className="font-heading tracking-wider text-xl">{weekLabel(selectedWeek)} Settings</h3>
                                <div className="flex gap-2">
                                  {selectedWeek > 1 && (
                                    <Button variant="outline" size="sm" onClick={handleCopyWeekFromPrevious} className="gap-2">
                                      <Copy className="h-4 w-4" /> Copy Previous Week
                                    </Button>
                                  )}
                                  <Select onValueChange={(v) => handleDuplicateWeekTo(parseInt(v))}>
                                    <SelectTrigger className="w-[160px] h-9"><SelectValue placeholder="Duplicate To..." /></SelectTrigger>
                                    <SelectContent>
                                      {Array.from({ length: newProgType === "GroupPT" ? 12 : newProgWeeks }).map((_, i) => (
                                        i + 1 !== selectedWeek && <SelectItem key={`dup-w-${i+1}`} value={(i + 1).toString()}>{weekLabel(i + 1)}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                  <Label>Week Label</Label>
                                  <Input
                                    placeholder={progWeekNotes[selectedWeek]?.start_date
                                      ? `W/C ${new Date(progWeekNotes[selectedWeek].start_date).toLocaleDateString()}`
                                      : `Week ${selectedWeek}`}
                                    value={progWeekNotes[selectedWeek]?.label || ""}
                                    onChange={e => setProgWeekNotes({...progWeekNotes, [selectedWeek]: { ...progWeekNotes[selectedWeek], label: e.target.value }})}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Week Start Date</Label>
                                  <Input 
                                    type="date"
                                    value={progWeekNotes[selectedWeek]?.start_date || ""}
                                    onChange={e => {
                                      const newDate = e.target.value;
                                      setProgWeekNotes({...progWeekNotes, [selectedWeek]: { ...progWeekNotes[selectedWeek], start_date: newDate }});
                                      // Group PT: auto-name each day of THIS week by its calendar date (Mon->Sat from the start date)
                                      if (newProgType === "GroupPT" && newDate) {
                                        setProgWorkouts(prev => prev.map(w =>
                                          w.week === selectedWeek
                                            ? { ...w, name: sessionDateName(newDate, (w.day || 1) - 1), scheduled_date: addDaysISO(newDate, (w.day || 1) - 1) }
                                            : w
                                        ));
                                      }
                                    }}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>Week Notes (Staff Only)</Label>
                                  <Input 
                                    placeholder="e.g. Focus on eccentric control this week..." 
                                    value={progWeekNotes[selectedWeek]?.notes || ""}
                                    onChange={e => setProgWeekNotes({...progWeekNotes, [selectedWeek]: { ...progWeekNotes[selectedWeek], notes: e.target.value }})}
                                  />
                                </div>
                              </div>
                              {newProgType === "GroupPT" && (
                                <Button variant="outline" size="sm" className="gap-2 ml-auto"
                                  onClick={async () => {
                                    const wk1 = progWeekNotes[1]?.start_date;
                                    const updated = progWorkouts.map(w => {
                                      const start = progWeekNotes[w.week]?.start_date || (wk1 ? addDaysISO(wk1, (w.week - 1) * 7) : null);
                                      if (!start) return w;
                                      return { ...w, name: sessionDateName(start, (w.day || 1) - 1), scheduled_date: addDaysISO(start, (w.day || 1) - 1) };
                                    });
                                    setProgWorkouts(updated);
                                    await autoSaveProgram(updated);
                                    toast.success("All sessions dated from their week start dates.");
                                  }}>
                                  <CalendarIcon className="h-4 w-4" /> Apply dates to all sessions
                                </Button>
                              )}
                            </div>
                          )}

                          <div className="flex items-center justify-between flex-wrap gap-4">
                            <div className="flex items-center gap-4 flex-wrap">
                              {newProgType !== "wow" && (
                                <div className="flex items-center gap-2">
                                  <Label className="whitespace-nowrap text-xs text-muted-foreground uppercase">Session Name / Theme</Label>
                                  <Input 
                                    value={progWorkouts[selectedWorkoutIndex]?.name || ""} 
                                    onChange={(e) => {
                                      const updatedWorkouts = [...progWorkouts];
                                      updatedWorkouts[selectedWorkoutIndex] = { ...updatedWorkouts[selectedWorkoutIndex], name: e.target.value };
                                      setProgWorkouts(updatedWorkouts);
                                    }}
                                    className="w-[200px] h-8 text-sm font-heading tracking-wider"
                                    placeholder={`Day ${progWorkouts[selectedWorkoutIndex]?.day || 1}`}
                                  />
                                {(() => {
                                  const workout = progWorkouts[selectedWorkoutIndex];
                                  const dayCounts = workout?.dayCounts;
                                  const minDays = workout?.minDays;
                                  if (!dayCounts && !minDays) return null;
                                  
                                  let label = "";
                                  let isTwoDay = false;
                                  if (dayCounts) {
                                    const counts = [...dayCounts].sort((a,b) => a-b);
                                    if (counts.length === 1 && counts[0] === 2) { label = "2-DAY PLAN"; isTwoDay = true; }
                                    else if (counts.length === 1) label = `${counts[0]}-DAY ONLY`;
                                    else if (counts.length === 4 && counts[0] === 2 && counts[3] === 5) label = "ALL PLANS";
                                    else if (counts.length > 1 && counts[counts.length-1] - counts[0] === counts.length - 1) label = `${counts[0]}-${counts[counts.length-1]} DAY`;
                                    else label = counts.join(",") + " DAY";
                                  } else if (minDays) {
                                    if (minDays === 2) label = "ALL PLANS";
                                    else if (minDays === 5) label = "5-DAY ONLY";
                                    else label = `${minDays}-5 DAY`;
                                  }

                                  return (
                                    <Badge variant={isTwoDay ? "default" : "outline"} className={cn("text-[10px] px-2 py-0.5 h-6 uppercase whitespace-nowrap", isTwoDay ? "bg-primary/20 text-primary border-primary/30" : "text-muted-foreground")}>
                                      {label}
                                    </Badge>
                                  );
                                  })()}
                                </div>
                              )}
                              {newProgType !== "wow" && (
                                <div className="flex items-center gap-2">
                                  <Label className="whitespace-nowrap text-xs text-muted-foreground uppercase">Scheduled Date</Label>
                                  <Input 
                                    type="date" 
                                  value={progWorkouts[selectedWorkoutIndex]?.date || ""} 
                                  onChange={(e) => {
                                    const updatedWorkouts = [...progWorkouts];
                                    updatedWorkouts[selectedWorkoutIndex] = { ...updatedWorkouts[selectedWorkoutIndex], date: e.target.value };
                                    setProgWorkouts(updatedWorkouts);
                                  }}
                                  className="w-[140px] h-8 text-sm"
                                  />
                                </div>
                              )}
                              {newProgType !== "wow" && (
                                <div className="flex items-center gap-2">
                                <Label className="whitespace-nowrap text-xs text-muted-foreground uppercase">Min Days</Label>
                                <Select 
                                  value={progWorkouts[selectedWorkoutIndex]?.minDays?.toString() || "0"} 
                                  onValueChange={(v) => {
                                    const updatedWorkouts = [...progWorkouts];
                                    updatedWorkouts[selectedWorkoutIndex] = { ...updatedWorkouts[selectedWorkoutIndex], minDays: parseInt(v, 10) || undefined };
                                    setProgWorkouts(updatedWorkouts);
                                  }}
                                >
                                  <SelectTrigger className="w-[100px] h-8 text-sm"><SelectValue placeholder="All" /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="0">All</SelectItem>
                                    <SelectItem value="2">2 Days</SelectItem>
                                    <SelectItem value="3">3 Days</SelectItem>
                                    <SelectItem value="4">4 Days</SelectItem>
                                    <SelectItem value="5">5 Days</SelectItem>
                                  </SelectContent>
                                </Select>
                                </div>
                              )}
                            </div>
                            <div className="flex gap-2">
                              {selectedWorkoutIndex > 0 && (
                                <Button variant="outline" size="sm" onClick={handleCopyFromPrevious} className="gap-2">
                                  <Copy className="h-4 w-4" /> Copy Previous Day
                                </Button>
                              )}
                              {(newProgType === "program" || newProgType === "GroupPT") && (
                                <Select onValueChange={(v) => handleDuplicateDayTo(selectedWeek, parseInt(v))}>
                                  <SelectTrigger className="w-[160px] h-9"><SelectValue placeholder="Duplicate To Day..." /></SelectTrigger>
                                  <SelectContent>
                                    {Array.from({ length: newProgType === "program" ? (newProgStream === "Stronger" ? 7 : 5) : newProgDays }).map((_, i) => (
                                      i + 1 !== selectedDay && <SelectItem key={`dup-d-${i+1}`} value={(i + 1).toString()}>Day {i + 1}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              )}
                              <Button variant="outline" size="sm" onClick={handleShuffleAll}>
                                Shuffle All
                              </Button>
                              {newProgType !== "wow" && (
                                <Button 
                                  variant="default" 
                                  size="sm" 
                                  className="gap-2 bg-primary text-primary-foreground"
                                  onClick={() => newProgType === "GroupPT" ? regenerateGroupCell(selectedWorkoutIndex) : handleEdgeFunctionAI(selectedWorkoutIndex, "regenerate")}
                                  disabled={isGeneratingAI}
                                >
                                  {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                                  Regenerate
                                </Button>
                              )}
                              {newProgType !== "GroupPT" && newProgType !== "wow" && (
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="gap-2"
                                  onClick={() => handleEdgeFunctionAI(selectedWorkoutIndex, "edit")}
                                  disabled={isGeneratingAI}
                                >
                                  {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Edit className="h-4 w-4" />}
                                  Edit with AI
                                </Button>
                              )}
                            </div>
                          </div>

                          <DragDropContext onDragEnd={onDragEnd}>
                            <Droppable droppableId="exercises-list">
                              {(provided) => (
                                <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                                  {(progWorkouts[selectedWorkoutIndex]?.exercises || []).length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed border-border rounded-lg bg-muted/20">
                                      <Dumbbell className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
                                      <p className="text-muted-foreground mb-4">No exercises added yet.</p>
                                      {newProgType !== "wow" && (
                                        <Button 
                                          onClick={() => newProgType === "GroupPT" ? regenerateGroupCell(selectedWorkoutIndex) : handleEdgeFunctionAI(selectedWorkoutIndex, "generate")} 
                                          className="gap-2 bg-primary text-primary-foreground"
                                          disabled={isGeneratingAI}
                                        >
                                          {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                                          Generate Workout with AI
                                        </Button>
                                      )}
                                    </div>
                                  ) : (
                                    (progWorkouts[selectedWorkoutIndex]?.exercises || []).map((pe: any, index: number) => (
                                    <Draggable key={pe.id?.toString() || `ex-${index}`} draggableId={pe.id?.toString() || `ex-${index}`} index={index}>
                                      {(provided) => (
                                        <div
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          className={`flex gap-4 items-center bg-background p-4 rounded-md border relative ${pe.linkedToNext ? 'border-b-0 rounded-b-none border-primary/50' : 'border-border'} ${index > 0 && progWorkouts[selectedWorkoutIndex].exercises[index - 1].linkedToNext ? 'border-t-0 rounded-t-none border-primary/50 bg-primary/5' : ''}`}
                                        >
                                          {(index > 0 && progWorkouts[selectedWorkoutIndex].exercises[index - 1].linkedToNext) && (
                                            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px] uppercase font-bold px-2 py-0.5 rounded-full flex items-center gap-1 z-20 shadow-sm border border-primary-foreground/20">
                                              <Link2 className="h-3 w-3" /> Superset
                                            </div>
                                          )}
                                          <div {...provided.dragHandleProps} className="cursor-grab text-muted-foreground hover:text-foreground">
                                            <GripVertical className="h-5 w-5" />
                                          </div>
                                          
                                          {pe.isSection ? (
                                            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                                              <div className="space-y-2">
                                                <Label>Section Title</Label>
                                                <Input value={pe.name} onChange={(e) => updateProgExercise(pe.id, "name", e.target.value)} placeholder="e.g. Warm Up" className="font-bold bg-muted/50" />
                                              </div>
                                              <div className="space-y-2">
                                                <Label>Section Type</Label>
                                                <Select value={pe.sectionType || "Normal"} onValueChange={(v) => updateProgExercise(pe.id, "sectionType", v)}>
                                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                                  <SelectContent>
                                                    <SelectItem value="Normal">Normal Block</SelectItem>
                                                    <SelectItem value="AMRAP">AMRAP Block</SelectItem>
                                                    <SelectItem value="EMOM">EMOM Block</SelectItem>
                                                    <SelectItem value="Circuit">Circuit Block</SelectItem>
                                                    <SelectItem value="AI Engine">AI Engine Builder</SelectItem>
                                                  </SelectContent>
                                                </Select>
                                              </div>
                                              <div className="space-y-2 md:col-span-2">
                                                <Label>Description / Time (Optional)</Label>
                                                <Textarea value={pe.description || ""} onChange={(e) => updateProgExercise(pe.id, "description", e.target.value)} placeholder={pe.sectionType === 'AMRAP' ? "e.g. 15 Minutes" : "e.g. Complete 3 rounds..."} className="min-h-[80px]" />
                                              </div>
                                              {pe.sectionType === "AI Engine" && (
                                                <div className="md:col-span-2 pt-2">
                                                  <Button 
                                                    variant="default" 
                                                    className="w-full gap-2 bg-primary text-primary-foreground font-bold tracking-wide"
                                                    onClick={() => handleGenerateEngineWorkout(pe.id)}
                                                    disabled={isGeneratingAI}
                                                  >
                                                    {isGeneratingAI ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} 
                                                    {isGeneratingAI ? "Generating..." : "Generate 40-Min Engine Workout"}
                                                  </Button>
                                                </div>
                                              )}
                                            </div>
                                          ) : (
                                            <div className="flex-1 flex flex-col gap-3">
                                              <div className="flex flex-col md:flex-row gap-2 md:items-center">
                                                <div className="w-full md:w-40 shrink-0">
                                                  <Select value={pe.blockType || "Strength"} onValueChange={(v) => {
                                                    const updatedWorkouts = [...progWorkouts];
                                                    const ex = updatedWorkouts[selectedWorkoutIndex].exercises.find((e: any) => e.id === pe.id);
                                                    if(ex) { ex.blockType = v; ex.name = ""; }
                                                    setProgWorkouts(updatedWorkouts);
                                                  }}>
                                                    <SelectTrigger className="h-10 bg-muted/20"><SelectValue placeholder="Block Type" /></SelectTrigger>
                                                    <SelectContent>
                                                      <SelectItem value="Strength">Strength</SelectItem>
                                                      <SelectItem value="Cardio">Cardio</SelectItem>
                                                      <SelectItem value="Mobility">Mobility</SelectItem>
                                                      <SelectItem value="Activation">Activation</SelectItem>
                                                    </SelectContent>
                                                  </Select>
                                                </div>
                                                <div className="flex-1 flex gap-2">
                                                  <Popover>
                                                    <PopoverTrigger asChild>
                                                      <Button
                                                        variant="outline"
                                                        role="combobox"
                                                        className={cn("h-10 font-medium justify-between flex-1 overflow-hidden", !pe.name && "text-muted-foreground")}
                                                      >
                                                        <span className="truncate">
                                                          {pe.name
                                                            ? exById[String(pe.name)]?.name || "Select Exercise..."
                                                            : "Select Exercise..."}
                                                        </span>
                                                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                                      </Button>
                                                    </PopoverTrigger>
                                                    <PopoverContent className="w-[300px] p-0" align="start">
                                                      <Command>
                                                        <CommandInput placeholder="Search exercises..." />
                                                        <CommandList>
                                                          <CommandEmpty>No exercise found.</CommandEmpty>
                                                          <CommandGroup>
                                                            {sortedExercises
                                                                .filter(ex => {
                                                                  if (!pe.blockType) return true;
                                                                  const cats = Array.isArray(ex.category) ? ex.category : [ex.category || "Strength"];
                                                                  const movs = Array.isArray(ex.movementType) ? ex.movementType : [ex.movementType || ""];
                                                                  return cats.includes(pe.blockType) || movs.includes(pe.blockType);
                                                                })
                                                              .map(ex => (
                                                                <CommandItem
                                                                  key={ex.id}
                                                                  value={ex.name}
                                                                  onSelect={() => {
                                                                    updateProgExercise(pe.id, "name", ex.id);
                                                                  }}
                                                                >
                                                                  <Check
                                                                    className={cn(
                                                                      "mr-2 h-4 w-4 shrink-0",
                                                                      pe.name === ex.id ? "opacity-100" : "opacity-0"
                                                                    )}
                                                                  />
                                                                  <span className="truncate">
                                                                    {ex.name} {ex.movementType ? `(${Array.isArray(ex.movementType) ? ex.movementType.join(", ") : ex.movementType})` : ""}
                                                                  </span>
                                                                </CommandItem>
                                                            ))}
                                                          </CommandGroup>
                                                        </CommandList>
                                                      </Command>
                                                    </PopoverContent>
                                                  </Popover>
                                                  <Button variant="outline" size="icon" className="h-10 w-10 shrink-0" onClick={() => handleShuffleExercise(pe.id)} title="Shuffle Exercise">
                                                    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.84998 7.49998C1.84998 4.66458 4.05979 2.23981 6.89998 1.92253V0.845728C3.47344 1.16915 0.849976 4.0402 0.849976 7.49998C0.849976 10.9598 3.47344 13.8308 6.89998 14.1542V13.0774C4.05979 12.7601 1.84998 10.3354 1.84998 7.49998ZM13.15 7.49998C13.15 10.3354 10.9402 12.7601 8.09998 13.0774V14.1542C11.5265 13.8308 14.15 10.9598 14.15 7.49998C14.15 4.0402 11.5265 1.16915 8.09998 0.845728V1.92253C10.9402 2.23981 13.15 4.66458 13.15 7.49998Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path></svg>
                                                  </Button>
                                                </div>
                                              </div>
                                              
                                              <div className="flex flex-wrap items-center gap-x-6 gap-y-3 bg-muted/20 p-3 rounded-md border border-border/50">
                                                  <div className="flex flex-wrap items-center gap-4">
                                                    {(() => {
                                                      const libEx = exById[String(pe.name)];
                                                      const rawTrack = libEx?.trackingType ?? "Weight & Reps";
                                                      const trackingArray = (Array.isArray(rawTrack) ? rawTrack : String(rawTrack).split(/[;,]/))
                                                        .map((s) => s.trim())
                                                        .filter(Boolean);

                                                      const canWR = trackingArray.includes('Weight & Reps');
                                                      const canWD = trackingArray.includes('Weight & Distance');
                                                      const canRepsOnly = trackingArray.includes('Reps Only');
                                                      const canTime = trackingArray.includes('Time Only') || trackingArray.includes('Distance & Time');
                                                      const canDist = trackingArray.includes('Distance & Time') || canWD;
                                                      const canCals = trackingArray.includes('Calories');

                                                      const hasBoth = canWR && canTime;
                                                      const activeMode = pe.trackingMode || (canWR ? 'reps' : canTime ? 'time' : 'reps');

                                                      const showWR = canWR && (!hasBoth || activeMode === 'reps');
                                                      const showWD = canWD;
                                                      const showRepsOnly = canRepsOnly;
                                                      const showTime = canTime && (!hasBoth || activeMode === 'time');

                                                      return (
                                                        <>
                                                          <div className="flex flex-col gap-1.5 w-16">
                                                            <Label className="text-[10px] uppercase text-muted-foreground font-bold">Sets</Label>
                                                            <Input type="number" className="h-8 text-center" value={pe.sets} onChange={(e) => updateProgExercise(pe.id, "sets", parseInt(e.target.value) || 0)} />
                                                          </div>
                                                          {hasBoth && (
                                                            <div className="flex flex-col gap-1.5 w-32 mr-2">
                                                              <Label className="text-[10px] uppercase text-muted-foreground font-bold">Mode</Label>
                                                              <div className="flex bg-muted/50 rounded-md p-0.5 border border-border">
                                                                <button 
                                                                  className={`flex-1 text-[10px] uppercase font-bold py-1 rounded-sm ${activeMode === 'reps' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
                                                                  onClick={() => {
                                                                    updateProgExercise(pe.id, "trackingMode", 'reps');
                                                                    updateProgExercise(pe.id, "timeMins", 0);
                                                                    updateProgExercise(pe.id, "timeSecs", 0);
                                                                  }}
                                                                >Reps</button>
                                                                <button 
                                                                  className={`flex-1 text-[10px] uppercase font-bold py-1 rounded-sm ${activeMode === 'time' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
                                                                  onClick={() => {
                                                                    updateProgExercise(pe.id, "trackingMode", 'time');
                                                                    updateProgExercise(pe.id, "reps", 0);
                                                                  }}
                                                                >Time</button>
                                                              </div>
                                                            </div>
                                                          )}
                                                          {showWR && (
                                                            <div className="flex flex-col gap-1.5 w-16">
                                                              <Label className="text-[10px] uppercase text-muted-foreground font-bold">Reps</Label>
                                                              <Input type="number" className="h-8 text-center" value={pe.reps} onChange={(e) => updateProgExercise(pe.id, "reps", parseInt(e.target.value) || 0)} />
                                                            </div>
                                                          )}
                                                          {showWD && (
                                                            <div className="flex flex-col gap-1.5 w-16">
                                                              <Label className="text-[10px] uppercase text-muted-foreground font-bold">KG</Label>
                                                              <Input type="number" className="h-8 text-center" value={pe.weight || 0} onChange={(e) => updateProgExercise(pe.id, "weight", parseFloat(e.target.value) || 0)} />
                                                            </div>
                                                          )}
                                                          {showRepsOnly && (
                                                            <div className="flex flex-col gap-1.5 w-16">
                                                              <Label className="text-[10px] uppercase text-muted-foreground font-bold">Reps</Label>
                                                              <Input type="number" className="h-8 text-center" value={pe.reps} onChange={(e) => updateProgExercise(pe.id, "reps", parseInt(e.target.value) || 0)} />
                                                            </div>
                                                          )}
                                                          {canDist && (
                                                            <div className="flex flex-col gap-1.5 w-20">
                                                              <Label className="text-[10px] uppercase text-muted-foreground font-bold">Metre</Label>
                                                              <Input type="number" className="h-8 text-center" value={pe.distance || 0} onChange={(e) => updateProgExercise(pe.id, "distance", parseInt(e.target.value) || 0)} />
                                                            </div>
                                                          )}
                                                          {showTime && (
                                                            <>
                                                              <div className="flex flex-col gap-1.5 w-16">
                                                                <Label className="text-[10px] uppercase text-muted-foreground font-bold">Mins</Label>
                                                                <Input type="number" className="h-8 text-center" value={pe.timeMins || 0} onChange={(e) => updateProgExercise(pe.id, "timeMins", parseInt(e.target.value) || 0)} />
                                                              </div>
                                                              <div className="flex flex-col gap-1.5 w-16">
                                                                <Label className="text-[10px] uppercase text-muted-foreground font-bold">Secs</Label>
                                                                <Input type="number" className="h-8 text-center" value={pe.timeSecs || 0} onChange={(e) => updateProgExercise(pe.id, "timeSecs", parseInt(e.target.value) || 0)} />
                                                              </div>
                                                            </>
                                                          )}
                                                          {canCals && (
                                                            <div className="flex flex-col gap-1.5 w-16">
                                                              <Label className="text-[10px] uppercase text-muted-foreground font-bold">Cals</Label>
                                                              <Input type="number" className="h-8 text-center" value={pe.calories || 0} onChange={(e) => updateProgExercise(pe.id, "calories", parseInt(e.target.value) || 0)} />
                                                            </div>
                                                          )}
                                                        </>
                                                      );
                                                    })()}
                                                  <div className="flex flex-col gap-1.5 w-16">
                                                    <Label className="text-[10px] uppercase text-muted-foreground font-bold">Rest(s)</Label>
                                                    <Input type="number" className="h-8 text-center" value={pe.rest || 0} onChange={(e) => updateProgExercise(pe.id, "rest", parseInt(e.target.value) || 0)} />
                                                  </div>
                                                </div>

                                                <div className="flex items-center gap-4 ml-auto">
                                                  {(newProgType === "program" || newProgType === "GroupPT") && (
                                                    <Button variant="secondary" size="sm" className="h-8 text-xs whitespace-nowrap" onClick={() => handleApplyToWeek(pe.id)}>
                                                      Apply to Week
                                                    </Button>
                                                  )}
                                                  <div className="flex items-center gap-2">
                                                    <Checkbox 
                                                      id={`eside-${pe.id}`}
                                                      checked={pe.eachSide} 
                                                      onCheckedChange={(c) => updateProgExercise(pe.id, "eachSide", !!c)} 
                                                    />
                                                    <Label htmlFor={`eside-${pe.id}`} className="text-xs font-medium cursor-pointer">Each Side</Label>
                                                  </div>
                                                  <Button 
                                                    variant={pe.linkedToNext ? "default" : "outline"} 
                                                    size="sm" 
                                                    className={`h-8 gap-1.5 ${pe.linkedToNext ? "bg-primary text-primary-foreground" : ""}`}
                                                    onClick={() => updateProgExercise(pe.id, "linkedToNext", !pe.linkedToNext)}
                                                    title={pe.linkedToNext ? "Unlink from next" : "Link to next as superset"}
                                                  >
                                                    {pe.linkedToNext ? <Link2Off className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
                                                    <span className="text-xs">Superset</span>
                                                  </Button>
                                                </div>
                                              </div>
                                              <div className="w-full">
                                                <Input 
                                                  placeholder="Coaching notes (visible to member)..." 
                                                  value={pe.coachingNotes || ""} 
                                                  onChange={(e) => updateProgExercise(pe.id, "coachingNotes", e.target.value)}
                                                  className="h-8 text-xs bg-background"
                                                />
                                              </div>
                                            </div>
                                          )}
                                          
                                          <Button variant="ghost" size="icon" className={`text-destructive shrink-0 self-center ${pe.isSection ? 'mt-6' : ''}`} onClick={() => handleRemoveProgExercise(pe.id)}>
                                            <Trash2 className="h-4 w-4" />
                                          </Button>
                                        </div>
                                      )}
                                    </Draggable>
                                  )))}
                                  {provided.placeholder}
                                </div>
                              )}
                            </Droppable>
                          </DragDropContext>

                          <div className="flex gap-2 justify-center pt-4 border-t border-border mt-4">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm" className="gap-2">
                                  <Heading className="h-4 w-4" /> Add Section
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                <DropdownMenuItem onClick={() => handleAddProgSection("Normal")}>Normal Block</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAddProgSection("AMRAP")}>AMRAP Block</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAddProgSection("EMOM")}>EMOM Block</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAddProgSection("Circuit")}>Circuit Block</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAddProgSection("AI Engine")}>AI Engine Builder</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                            <Button variant="outline" size="sm" onClick={handleAddProgExercise} className="gap-2">
                              <Plus className="h-4 w-4" /> Add Exercise
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div className="flex gap-2 mt-6 pt-6 border-t border-border">
                <Button onClick={handleAddProgram} className="flex-1 gap-2">
                  <Dumbbell className="h-4 w-4" /> {editingProgramId ? (newProgType === "wow" ? "Update WOW" : "Update Program") : (newProgType === "wow" ? "Save WOW" : "Save Program")}
                </Button>
                {editingProgramId && (
                  <Button variant="outline" onClick={() => {
                    setEditingProgramId(null);
                    setNewProgName("");
                    setNewProgDesc("");
                    setProgWorkouts([]);
                    if (newProgType === "wow") {
                      setActiveTab("wow");
                    }
                  }}>
                    Cancel
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="flex items-center justify-between mt-6 mb-4">
            <h3 className="text-xl font-heading tracking-wider">Existing Programs</h3>
            <Button variant="outline" className="gap-2" onClick={handleExportProgramsData}>
              <Download className="h-4 w-4" /> Backup to JSON
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {programs.map((p) => (
              <Card key={p.id} className="bg-muted/50 border-border">
                <CardHeader>
                  <CardTitle className="flex justify-between items-start">
                    <span>{p.name}</span>
                    <div className="flex gap-1 -mt-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => handleEditProgram(p)} title="Edit Program">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => handleDuplicateProgram(p.id)} title="Duplicate Program">
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => handleDeleteProgram(p.id)} title="Delete Program">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardTitle>
                  <CardDescription>{p.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground mt-2">
                    {p.weeks && p.daysPerWeek ? (
                      <div className="space-y-4">
                        <p>{p.weeks} Weeks • {p.daysPerWeek} Days/Week</p>
                        {p.workouts && p.workouts.length > 0 && (() => {
                          const byWeek: Record<number, { w: any; idx: number }[]> = {};
                          p.workouts.forEach((w: any, idx: number) => {
                            const wk = w.week || 1;
                            (byWeek[wk] ||= []).push({ w, idx });
                          });
                          const weeks = Object.keys(byWeek).map(Number).sort((a, b) => a - b);
                          const tvWeekLabel = (wk: number) => {
                            const n = p.weekNotes?.[wk];
                            if (n?.label?.trim()) return n.label.trim();
                            if (n?.start_date) return `W/C ${new Date(n.start_date + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short" })}`;
                            return `Week ${wk}`;
                          };
                          return (
                            <div className="space-y-2">
                              <Label className="text-xs uppercase text-muted-foreground">Workouts (TV Display)</Label>
                              <Accordion type="multiple" className="w-full">
                                {weeks.map((wk) => (
                                  <AccordionItem key={wk} value={`tvwk-${wk}`}>
                                    <AccordionTrigger className="text-sm font-bold">{tvWeekLabel(wk)}</AccordionTrigger>
                                    <AccordionContent>
                                      <div className="grid grid-cols-2 gap-2">
                                        {byWeek[wk].sort((a, b) => (a.w.day || 0) - (b.w.day || 0)).map(({ w, idx }) => (
                                          <Button key={idx} variant="outline" size="sm" className="justify-start gap-2 h-auto py-2"
                                            onClick={() => window.open(`/tv/${p.id}/${idx}`, '_blank')}>
                                            <PlayCircle className="h-4 w-4 shrink-0 text-primary" />
                                            <span className="truncate">{w.name}</span>
                                          </Button>
                                        ))}
                                      </div>
                                    </AccordionContent>
                                  </AccordionItem>
                                ))}
                              </Accordion>
                            </div>
                          );
                        })()}
                      </div>
                    ) : (
                      <ul className="list-disc list-inside">
                        {p.exercises?.map((ex: any, i: number) => {
                          if (ex.isSection) return <li key={i} className="font-bold mt-2 list-none">{ex.name}</li>;
                          const exerciseName = exById[String(ex.name)]?.name || ex.name;
                          return <li key={i}>{exerciseName} - {ex.sets}x{ex.reps}</li>;
                        })}
                      </ul>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="wow" className="space-y-6 mt-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-heading text-2xl uppercase">Workout of the Week</h3>
            <Button onClick={() => {
              setEditingProgramId(null);
              setNewProgType("wow");
              setNewProgName("");
              setNewProgDesc("");
              setWowScoreType("time");
              setWowScaledAllowed(true);
              setWowWeekStart("");
              setProgWorkouts([{ week: 1, day: 1, date: "", name: "Workout of the Week", exercises: [] }]);
              setActiveTab("programs");
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} className="gap-2">
              <Plus className="h-4 w-4" /> Create New WOW
            </Button>
          </div>

          <h3 className="font-heading text-2xl uppercase mt-8 mb-4">Past WOWs</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {wows.map(w => (
              <Card key={w.id} className="bg-card border-border">
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <h4 className="font-bold">{w.name}</h4>
                    <p className="text-sm text-muted-foreground">W/C {new Date(w.week_start).toLocaleDateString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => {
                      setEditingProgramId(w.id);
                      setNewProgType("wow");
                      setNewProgName(w.name);
                      setNewProgDesc(w.description || "");
                      setWowScoreType(w.score_type || "time");
                      setWowScaledAllowed(w.scaled_allowed ?? true);
                      setWowWeekStart(w.week_start || "");
                      setProgWorkouts([{ week: 1, day: 1, date: "", name: "Workout of the Week", exercises: w.exercises || [] }]);
                      // Switch to programs tab
                      setActiveTab("programs");
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}>Edit in Builder</Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDeleteWow(w.id)}>Delete</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>


        <TabsContent value="members" className="space-y-6 mt-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <Card className="flex-1 bg-card border-border">
              <CardHeader>
                <CardTitle>Invite Member</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input value={inviteName} onChange={e => setInviteName(e.target.value)} placeholder="Jane Doe" />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input type="email" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} placeholder="jane@example.com" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Allowed Access</Label>
                  <div className="flex flex-wrap gap-4">
                    {["Foundations", "Stronger", "Fusion", "Performance", "Group PT"].map(acc => (
                      <div key={acc} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`inv-${acc}`} 
                          checked={inviteAllowed.includes(acc)}
                          onCheckedChange={(c) => {
                            if (c) setInviteAllowed([...inviteAllowed, acc]);
                            else setInviteAllowed(inviteAllowed.filter(a => a !== acc));
                          }}
                        />
                        <Label htmlFor={`inv-${acc}`}>{acc}</Label>
                      </div>
                    ))}
                  </div>
                </div>
                <Button onClick={handleInvite} disabled={isInviting || !inviteName || !inviteEmail}>
                  {isInviting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Users className="h-4 w-4 mr-2" />}
                  Send Invite
                </Button>
              </CardContent>
            </Card>
            <Card className="flex-1 bg-card border-border">
              <CardHeader>
                <CardTitle>Bulk Import</CardTitle>
                <CardDescription>Upload a CSV with columns: name, email, access (optional, semicolon separated)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <Input type="file" accept=".csv" onChange={handleBulkInvite} disabled={isBulkInviting} />
                  {isBulkInviting && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {members.map((member) => (
              <Card key={member.id} className="bg-card border-border flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
                      {member.full_name?.charAt(0).toUpperCase() || "U"}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{member.full_name}</CardTitle>
                      <CardDescription className="text-xs">{member.email}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-4">
                  <div className="space-y-2 flex-1">
                    <Label className="text-xs text-muted-foreground">Access</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {["Foundations", "Stronger", "Fusion", "Performance", "Group PT"].map(acc => {
                        const hasAccess = (member.allowed_access || []).includes(acc);
                        return (
                          <div key={acc} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`mem-${member.id}-${acc}`} 
                              checked={hasAccess}
                              onCheckedChange={(c) => handleSetAccess(member.id, acc, !!c)}
                            />
                            <Label htmlFor={`mem-${member.id}-${acc}`} className="text-xs">{acc}</Label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full gap-2 mt-auto"
                    onClick={() => handleViewActivity(member)}
                  >
                    <History className="h-4 w-4" /> View Activity
                  </Button>
                </CardContent>
              </Card>
            ))}
            {members.length === 0 && (
              <div className="col-span-full text-center py-12 text-muted-foreground bg-muted/20 rounded-lg border border-dashed">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>No members found yet. Members will appear here once they log in.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="nutrition" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg">Nutrition Sections</CardTitle>
              <CardDescription>Switch a section on when it's ready — members see it instantly.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { flag: 'nutrition_calculator', label: 'Calorie Calculator' },
                { flag: 'nutrition_progress',   label: 'Progress' },
                { flag: 'nutrition_habits',      label: 'Habit Tracking' },
                { flag: 'nutrition_recipes',     label: 'Recipes' },
                { flag: 'nutrition_meal_plans',  label: 'Meal Plans' },
                { flag: 'nutrition_education',   label: 'Education' },
              ].map(s => (
                <div key={s.flag} className="flex items-center justify-between gap-2 p-3 rounded-lg border border-border bg-muted/30">
                  <Label className="text-sm font-bold cursor-pointer">{s.label}</Label>
                  <Switch
                    checked={appFlags?.[s.flag] ?? false}
                    onCheckedChange={(v) => toggleFlag(s.flag, v)}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <h3 className="text-2xl font-heading tracking-wider">Nutrition</h3>
              <div className="flex bg-muted p-1 rounded-lg">
                <Button 
                  variant={nutritionSubView === "coaching" ? "default" : "ghost"} 
                  size="sm" 
                  className="h-8 text-xs px-4"
                  onClick={() => setNutritionSubView("coaching")}
                >
                  Coaching
                </Button>
                <Button 
                  variant={nutritionSubView === "library" ? "default" : "ghost"} 
                  size="sm" 
                  className="h-8 text-xs px-4"
                  onClick={() => setNutritionSubView("library")}
                >
                  Habit Library
                </Button>
              </div>
            </div>

            {nutritionSubView === "coaching" ? (
              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <Input 
                  placeholder="Search members..." 
                  value={nutritionSearch} 
                  onChange={e => setNutritionSearch(e.target.value)}
                  className="max-w-[200px] h-9"
                />
                <Select value={nutritionFilter} onValueChange={(v: any) => setNutritionFilter(v)}>
                  <SelectTrigger className="w-[130px] h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Members</SelectItem>
                    <SelectItem value="attention">Needs Attention</SelectItem>
                    <SelectItem value="coached">1-1 Coached</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={loadNutritionMembers} className="h-9"><History className="h-4 w-4 mr-2"/> Refresh</Button>
              </div>
            ) : (
              <Button variant="outline" size="sm" onClick={loadHabitLibrary} className="h-9"><History className="h-4 w-4 mr-2"/> Refresh Library</Button>
            )}
          </div>

          {nutritionSubView === "coaching" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {nutritionMembers
                .filter(m => {
                  const matchesSearch = m.name?.toLowerCase().includes(nutritionSearch.toLowerCase()) || m.email?.toLowerCase().includes(nutritionSearch.toLowerCase());
                  const requiresAttention = m.consistency < 50 || (m.lastCheckin && new Date().getTime() - new Date(m.lastCheckin).getTime() > 3 * 24 * 60 * 60 * 1000);
                  
                  if (nutritionFilter === "attention") return matchesSearch && requiresAttention;
                  if (nutritionFilter === "coached") return matchesSearch && m.coached;
                  return matchesSearch;
                })
                .sort((a, b) => {
                  const aAttn = a.consistency < 50 || (a.lastCheckin && new Date().getTime() - new Date(a.lastCheckin).getTime() > 3 * 24 * 60 * 60 * 1000);
                  const bAttn = b.consistency < 50 || (b.lastCheckin && new Date().getTime() - new Date(b.lastCheckin).getTime() > 3 * 24 * 60 * 60 * 1000);
                  if (aAttn && !bAttn) return -1;
                  if (!aAttn && bAttn) return 1;
                  return 0;
                })
                .map((member: any) => {
                  const noCheckinDays = member.lastCheckin ? Math.floor((new Date().getTime() - new Date(member.lastCheckin).getTime()) / (24 * 60 * 60 * 1000)) : 999;
                  const requiresAttention = member.consistency < 50 || noCheckinDays >= 3;
                  
                  return (
                    <Card key={member.memberId} className={cn("bg-card border-border relative overflow-hidden", requiresAttention && "border-destructive/50 ring-1 ring-destructive/20")}>
                      {requiresAttention && (
                        <div className="absolute top-0 right-0 p-1">
                          <Badge variant="destructive" className="text-[8px] uppercase px-1 h-4">Attention</Badge>
                        </div>
                      )}
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{member.name || 'Unknown'}</CardTitle>
                            <CardDescription className="text-xs">{member.email}</CardDescription>
                          </div>
                          {member.coached && <span className="bg-primary/20 text-primary text-[10px] px-2 py-0.5 rounded font-bold uppercase">Coached</span>}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="bg-muted p-2 rounded">
                            <span className="text-muted-foreground text-[10px] uppercase font-bold block">Goal</span>
                            <span className="font-medium capitalize text-xs">{member.goal?.replace('_', ' ') || 'None'}</span>
                          </div>
                          <div className="bg-muted p-2 rounded">
                            <span className="text-muted-foreground text-[10px] uppercase font-bold block">Consistency</span>
                            <span className={cn("font-medium text-xs", member.consistency < 50 ? "text-destructive" : "text-primary")}>{member.consistency}%</span>
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <Label className="text-[10px] uppercase font-bold text-muted-foreground">Active Habit(s)</Label>
                          {member.activeHabits?.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {member.activeHabits.map((h: any) => (
                                <Badge key={h.id} variant="outline" className="text-[10px] bg-primary/5 border-primary/20 text-primary py-0 h-5">
                                  {h.name}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <p className="text-xs text-muted-foreground italic">None active</p>
                          )}
                          {noCheckinDays > 0 && (
                            <p className={cn("text-[10px] font-bold uppercase mt-1", noCheckinDays >= 3 ? "text-destructive" : "text-muted-foreground")}>
                              Last check-in: {noCheckinDays === 999 ? 'Never' : `${noCheckinDays}d ago`}
                            </p>
                          )}
                        </div>

                        <div className="pt-2 space-y-3 border-t border-border">
                          <div className="flex items-center justify-between">
                            <Label htmlFor={`coached-${member.memberId}`} className="text-xs font-bold uppercase cursor-pointer">1-1 Coached Tier</Label>
                            <Checkbox 
                              id={`coached-${member.memberId}`}
                              checked={member.coached}
                              onCheckedChange={(c) => handleSetCoached(member.memberId, !!c)}
                            />
                          </div>
                          
                          <div className="space-y-1">
                            <Label className="text-[10px] uppercase font-bold">Override Next Habit</Label>
                            <Select onValueChange={(v) => handleSetNextHabit(member.memberId, parseInt(v))}>
                              <SelectTrigger className="h-8 text-xs">
                                <SelectValue placeholder="Select habit..." />
                              </SelectTrigger>
                              <SelectContent>
                                {nutritionHabits.map((h: any) => (
                                  <SelectItem key={h.id} value={h.id?.toString() || ""}>{h.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-1">
                            <Label className="text-[10px] uppercase font-bold">Coach Note / Macro Targets</Label>
                            <div className="flex gap-2">
                              <Input 
                                id={`note-${member.memberId}`} 
                                placeholder="e.g. Aim for 180g Protein..." 
                                className="h-8 text-xs" 
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    const target = e.target as HTMLInputElement;
                                    if (target.value.trim()) {
                                      handleAddCoachNote(member.memberId, member.activeHabits?.[0]?.id, target.value.trim());
                                      target.value = '';
                                    }
                                  }
                                }}
                              />
                              <Button 
                                size="sm" 
                                className="h-8 w-8 p-0"
                                onClick={() => {
                                  const input = document.getElementById(`note-${member.memberId}`) as HTMLInputElement;
                                  if (input?.value.trim()) {
                                    handleAddCoachNote(member.memberId, member.activeHabits?.[0]?.id, input.value.trim());
                                    input.value = '';
                                  }
                                }}
                              ><Send className="h-3 w-3" /></Button>
                            </div>
                          </div>
                          
                          {member.coached && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" className="w-full h-8 text-xs">Set Macro Targets</Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Set Macros for {member.name}</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                      <Label>Calories</Label>
                                      <Input id={`mac-cal-${member.memberId}`} type="number" defaultValue={member.macros?.calorie_target || ''} />
                                    </div>
                                    <div className="space-y-2">
                                      <Label>Protein (g)</Label>
                                      <Input id={`mac-pro-${member.memberId}`} type="number" defaultValue={member.macros?.protein_target || ''} />
                                    </div>
                                    <div className="space-y-2">
                                      <Label>Carbs (g)</Label>
                                      <Input id={`mac-crb-${member.memberId}`} type="number" defaultValue={member.macros?.carb_target || ''} />
                                    </div>
                                    <div className="space-y-2">
                                      <Label>Fat (g)</Label>
                                      <Input id={`mac-fat-${member.memberId}`} type="number" defaultValue={member.macros?.fat_target || ''} />
                                    </div>
                                  </div>
                                  <Button className="w-full" onClick={() => {
                                    const cal = parseInt((document.getElementById(`mac-cal-${member.memberId}`) as HTMLInputElement).value);
                                    const pro = parseInt((document.getElementById(`mac-pro-${member.memberId}`) as HTMLInputElement).value);
                                    const crb = parseInt((document.getElementById(`mac-crb-${member.memberId}`) as HTMLInputElement).value);
                                    const fat = parseInt((document.getElementById(`mac-fat-${member.memberId}`) as HTMLInputElement).value);
                                    handleSetMacros(member.memberId, {
                                      calorie_target: cal,
                                      protein_target: pro,
                                      carb_target: crb,
                                      fat_target: fat,
                                      tracking_enabled: true
                                    });
                                  }}>Save Macros</Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              {nutritionMembers.length === 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground bg-muted/20 rounded-lg border border-dashed">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-20" />
                  <p>No nutrition members found yet.</p>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-8">
              {[1, 2, 3].map(phase => {
                const phaseHabits = habitLibrary.filter(h => h.phase === phase);
                if (phaseHabits.length === 0) return null;
                
                return (
                  <section key={phase} className="space-y-4">
                    <div className="flex items-center gap-2 border-b pb-2 border-border/50">
                      <Badge className="bg-primary text-primary-foreground font-bold uppercase tracking-wider text-[10px]">Phase {phase}</Badge>
                      <h4 className="font-heading text-xl uppercase tracking-tight text-foreground/80">
                        {phase === 1 ? "Foundations" : phase === 2 ? "Building" : "Performance"}
                      </h4>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      {phaseHabits.map(habit => (
                        <Card key={habit.id} className="bg-card border-border overflow-hidden">
                          <CardContent className="p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                            <div className="flex-1 min-w-0 space-y-2">
                              <h5 className="font-bold text-lg">{habit.name}</h5>
                              <p className="text-xs text-muted-foreground line-clamp-1">{habit.coaching_cue}</p>
                              
                              <div className="grid grid-cols-2 gap-4 mt-2">
                                <div className="space-y-1">
                                  <Label className="text-[10px] uppercase">Check-in Type</Label>
                                  <Select 
                                    defaultValue={habit.checkin_type || "tick"} 
                                    onValueChange={(v) => handleUpdateHabit(habit.id, { checkin_type: v })}
                                  >
                                    <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="tick">Tick (Once)</SelectItem>
                                      <SelectItem value="count">Count (Multiple)</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="space-y-1">
                                  <Label className="text-[10px] uppercase">Days to Graduate</Label>
                                  <Input 
                                    type="number" 
                                    className="h-8 text-xs" 
                                    defaultValue={habit.days_to_graduate || 21}
                                    onBlur={(e) => handleUpdateHabit(habit.id, { days_to_graduate: parseInt(e.target.value) || 21 })}
                                  />
                                </div>
                                {habit.checkin_type === 'count' && (
                                  <>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] uppercase">Count Target</Label>
                                      <Input 
                                        type="number" 
                                        className="h-8 text-xs" 
                                        defaultValue={habit.count_target || 1}
                                        onBlur={(e) => handleUpdateHabit(habit.id, { count_target: parseInt(e.target.value) || 1 })}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] uppercase">Count Unit</Label>
                                      <Input 
                                        className="h-8 text-xs" 
                                        defaultValue={habit.count_unit || "times"}
                                        onBlur={(e) => handleUpdateHabit(habit.id, { count_unit: e.target.value })}
                                      />
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-2 w-full md:w-auto mt-4 md:mt-0">
                              <div className="relative flex-1 md:w-72">
                                <Input 
                                  placeholder="Video URL (Vimeo/YouTube)" 
                                  className="h-9 text-xs pr-10"
                                  defaultValue={habit.video_url || ""}
                                  id={`habit-vid-${habit.id}`}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      const target = e.target as HTMLInputElement;
                                      handleUpdateHabit(habit.id, { video_url: target.value });
                                    }
                                  }}
                                />
                                {habit.video_url && (
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="ghost" size="icon" className="h-7 w-7 absolute right-1.5 top-1 text-primary hover:text-primary/80 hover:bg-primary/10">
                                        <PlayCircle className="h-5 w-5" />
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-black border-none">
                                      <DialogHeader className="p-4 absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/80 to-transparent">
                                        <DialogTitle className="text-white">{habit.name}</DialogTitle>
                                      </DialogHeader>
                                      <div className="aspect-video w-full mt-10">
                                        <iframe
                                          src={getEmbedUrl(habit.video_url)}
                                          className="w-full h-full"
                                          allow="autoplay; fullscreen; picture-in-picture"
                                          allowFullScreen
                                        />
                                      </div>
                                    </DialogContent>
                                  </Dialog>
                                )}
                              </div>
                              <Button 
                                size="sm" 
                                className="h-9 gap-2"
                                disabled={isUpdatingHabit === habit.id}
                                onClick={() => {
                                  const input = document.getElementById(`habit-vid-${habit.id}`) as HTMLInputElement;
                                  handleUpdateHabit(habit.id, { video_url: input?.value || "" });
                                }}
                              >
                                {isUpdatingHabit === habit.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                                Save
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </section>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Broadcast Notification</CardTitle>
              <CardDescription>Send a message to all members currently using the app.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={notifTitle} onChange={e => setNotifTitle(e.target.value)} placeholder="e.g. New Equipment Alert!" />
              </div>
              <div className="space-y-2">
                <Label>Message</Label>
                <Input value={notifMessage} onChange={e => setNotifMessage(e.target.value)} placeholder="e.g. We just added 3 new squat racks to the main floor." />
              </div>
              <Button onClick={handleSendBroadcast} disabled={isSendingNotif} className="gap-2">
                {isSendingNotif ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                Send Broadcast
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Export Source Code</CardTitle>
              <CardDescription>Download a ZIP file of the entire project so you can host it on Netlify.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={handleDownloadSource} disabled={isZipping} className="gap-2">
                {isZipping ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                Download Source ZIP
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Vimeo Integration</CardTitle>
              <CardDescription>Sync your Vimeo videos as exercises automatically.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Vimeo Personal Access Token</Label>
                <Input 
                  type="password" 
                  value={vimeoToken} 
                  onChange={e => {
                    setVimeoToken(e.target.value);
                    saveVimeoToken(e.target.value);
                  }} 
                  placeholder="Enter your Vimeo token" 
                />
              </div>
              <Button 
                onClick={handleSyncVimeo} 
                disabled={isSyncing || !vimeoToken}
                className="gap-2"
              >
                {isSyncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Video className="h-4 w-4" />}
                {isSyncing ? "Syncing..." : "Sync Videos"}
              </Button>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border mt-6">
            <CardHeader>
              <CardTitle>Force Cloud Sync</CardTitle>
              <CardDescription>If your exercises or programs aren't showing up on the live site, click this to force push your local data to the database.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={async () => {
                if (exercises.length === 0 && programs.length === 0) {
                  toast.error("Both exercises and programs are empty locally. Aborting to prevent accidental deletion.");
                  return;
                }
                
                toast.info("Syncing to cloud...");
                let exRes = null;
                let progRes = null;
                
                if (exercises.length > 0) {
                  exRes = await saveExercises(exercises);
                }
                if (programs.length > 0) {
                  progRes = await savePrograms(programs);
                }
                
                if ((exRes && exRes.error) || (progRes && progRes.error)) {
                  toast.error("Sync failed: " + (exRes?.error?.message || progRes?.error?.message), { duration: 10000 });
                } else {
                  toast.success("Successfully synced exercises and programs to cloud!");
                }
              }} className="gap-2">
                <History className="h-4 w-4" /> Force Push to Cloud
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Schedule Workouts</CardTitle>
              <CardDescription>Assign programs or specific sessions to dates.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-md border bg-card"
                  />
                </div>
                <div className="space-y-4">
                  <h3 className="text-lg font-bold">
                    {selectedDate ? `Schedule for ${selectedDate.toLocaleDateString()}` : "Select a date"}
                  </h3>
                  {selectedDate && (
                    <>
                      <div className="space-y-2">
                        <Label>Select Program</Label>
                        <Select value={scheduleProgramId} onValueChange={(v) => { setScheduleProgramId(v); setScheduleWorkoutId(''); }}>
                          <SelectTrigger><SelectValue placeholder="Select a program" /></SelectTrigger>
                          <SelectContent>
                            {programs.map(p => (
                              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {scheduleProgramId && (
                        <div className="space-y-2">
                          <Label>Select Session</Label>
                          <Select value={scheduleWorkoutId} onValueChange={setScheduleWorkoutId}>
                            <SelectTrigger><SelectValue placeholder="Select a session" /></SelectTrigger>
                            <SelectContent>
                              {programs.find(p => p.id === scheduleProgramId)?.workouts?.map((w: any, idx: number) => (
                                <SelectItem key={idx} value={idx.toString()}>{w.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                      <Button 
                        className="w-full"
                        disabled={!scheduleProgramId || !scheduleWorkoutId}
                        onClick={() => {
                          const dateStr = selectedDate.toISOString().split('T')[0];
                          const newEvent = {
                            id: Date.now().toString(),
                            date: dateStr,
                            programId: scheduleProgramId,
                            workoutIndex: scheduleWorkoutId,
                            programName: programs.find(p => p.id === scheduleProgramId)?.name,
                            workoutName: programs.find(p => p.id === scheduleProgramId)?.workouts[parseInt(scheduleWorkoutId)]?.name
                          };
                          saveScheduledEvents([...scheduledEvents, newEvent]);
                          toast.success("Scheduled successfully!");
                          setScheduleProgramId('');
                          setScheduleWorkoutId('');
                        }}
                      >
                        Schedule Session
                      </Button>

                      <div className="pt-6">
                        <h4 className="font-bold mb-2">Scheduled on this date:</h4>
                        <div className="space-y-2">
                          {scheduledEvents.filter(e => e.date === selectedDate.toISOString().split('T')[0]).map(event => (
                            <div key={event.id} className="flex items-center justify-between p-3 border border-border rounded-md bg-muted/30">
                              <div>
                                <div className="font-bold text-sm">{event.programName}</div>
                                <div className="text-xs text-muted-foreground">{event.workoutName}</div>
                              </div>
                              <Button variant="ghost" size="icon" className="text-destructive" onClick={() => {
                                saveScheduledEvents(scheduledEvents.filter(e => e.id !== event.id));
                              }}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                          {scheduledEvents.filter(e => e.date === selectedDate.toISOString().split('T')[0]).length === 0 && (
                            <div className="text-sm text-muted-foreground">No sessions scheduled.</div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="display" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>TV Display Settings</CardTitle>
              <CardDescription>Manage presets and launch the TV display for your programs.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-bold">Launch Display</h3>
                  <div className="space-y-2">
                    <Label>Select Program</Label>
                    <Select value={selectedDisplayProgramId} onValueChange={(v) => { setSelectedDisplayProgramId(v); setSelectedDisplayWorkoutId(''); }}>
                      <SelectTrigger><SelectValue placeholder="Select a program" /></SelectTrigger>
                      <SelectContent>
                        {programs.map(p => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {selectedDisplayProgramId && (
                    <div className="space-y-2">
                      <Label>Select Session</Label>
                      <Select value={selectedDisplayWorkoutId} onValueChange={setSelectedDisplayWorkoutId}>
                        <SelectTrigger><SelectValue placeholder="Select a session" /></SelectTrigger>
                        <SelectContent>
                          {programs.find(p => p.id === selectedDisplayProgramId)?.workouts?.map((w: any, idx: number) => (
                            <SelectItem key={idx} value={idx.toString()}>{w.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label>Select Preset</Label>
                    <Select value={selectedPresetId} onValueChange={setSelectedPresetId}>
                      <SelectTrigger><SelectValue placeholder="Select a preset" /></SelectTrigger>
                      <SelectContent>
                        {displayPresets.map(p => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    className="w-full gap-2" 
                    disabled={!selectedDisplayProgramId || !selectedDisplayWorkoutId}
                    onClick={() => window.open(`/tv/${selectedDisplayProgramId}/${selectedDisplayWorkoutId}?preset=${selectedPresetId}`, '_blank')}
                  >
                    <PlayCircle className="h-4 w-4" /> Launch TV Display
                  </Button>
                </div>
                
                <div className="space-y-4 border-l border-border pl-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold">Manage Presets</h3>
                    <Button variant="outline" size="sm" onClick={() => {
                      const newId = 'preset_' + Date.now();
                      savePresets([...displayPresets, { ...displayPresets[0], id: newId, name: 'New Preset' }]);
                      setEditingPresetId(newId);
                    }}>
                      <Plus className="h-4 w-4 mr-2" /> New Preset
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    {displayPresets.map(preset => (
                      <div key={preset.id} className="flex items-center justify-between p-3 border border-border rounded-md bg-muted/30">
                        <span>{preset.name}</span>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" onClick={() => setEditingPresetId(preset.id)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          {preset.id !== 'default' && (
                            <Button variant="ghost" size="icon" className="text-destructive" onClick={() => {
                              savePresets(displayPresets.filter(p => p.id !== preset.id));
                              if (selectedPresetId === preset.id) setSelectedPresetId('default');
                            }}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6 mt-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>AI Settings</CardTitle>
              <CardDescription>Configure your AI brain (Claude) for automatic workout generation.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Anthropic API Key</Label>
                <Input 
                  type="password" 
                  value={anthropicKey} 
                  onChange={e => {
                    setAnthropicKey(e.target.value);
                    saveAnthropicKey(e.target.value);
                  }} 
                  placeholder="sk-ant-api03-..." 
                />
                <p className="text-xs text-muted-foreground pt-1">
                  Your API key is stored securely on your device and synced to your profile. It is used directly from your browser to call Claude.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <Dialog open={!!editingPresetId} onOpenChange={(open) => !open && setEditingPresetId(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Display Preset</DialogTitle>
            </DialogHeader>
            {editingPresetId && (() => {
              const preset = displayPresets.find(p => p.id === editingPresetId);
              if (!preset) return null;
              
              const updatePreset = (field: string, subfield: string | null, value: any) => {
                const updated = displayPresets.map(p => {
                  if (p.id === editingPresetId) {
                    if (subfield) {
                      return { ...p, [field]: { ...p[field], [subfield]: value } };
                    }
                    return { ...p, [field]: value };
                  }
                  return p;
                });
                savePresets(updated);
              };

              return (
                <div className="space-y-6 py-4">
                  <div className="space-y-2">
                    <Label>Preset Name</Label>
                    <Input value={preset.name} onChange={e => updatePreset('name', null, e.target.value)} />
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-bold border-b pb-2">Layout</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Orientation</Label>
                        <Select value={preset.layout.orientation} onValueChange={v => updatePreset('layout', 'orientation', v)}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="landscape">Landscape</SelectItem>
                            <SelectItem value="portrait">Portrait</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex items-center space-x-2 pt-8">
                        <Checkbox id="showRest" checked={preset.layout.showRest} onCheckedChange={c => updatePreset('layout', 'showRest', !!c)} />
                        <label htmlFor="showRest" className="text-sm">Show Rest Times</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="showHeaders" checked={preset.layout.showHeaders} onCheckedChange={c => updatePreset('layout', 'showHeaders', !!c)} />
                        <label htmlFor="showHeaders" className="text-sm">Show Column Headers</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="showDuration" checked={preset.layout.showDuration} onCheckedChange={c => updatePreset('layout', 'showDuration', !!c)} />
                        <label htmlFor="showDuration" className="text-sm">Show Duration</label>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-bold border-b pb-2">Colors</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Background Color</Label>
                        <Input type="color" value={preset.colors.background} onChange={e => updatePreset('colors', 'background', e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Block Color</Label>
                        <Input type="color" value={preset.colors.blockBackground} onChange={e => updatePreset('colors', 'blockBackground', e.target.value)} />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
            <DialogFooter>
              <Button onClick={() => setEditingPresetId(null)}>Done</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </Tabs>
    </div>
  );
};

export default Admin;
